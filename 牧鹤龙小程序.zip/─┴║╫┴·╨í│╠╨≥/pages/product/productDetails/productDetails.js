// pages/product/productDetails/productDetails.js
var dataId = getApp().dataId;
var app = getApp();
var id;
var goodsid;
var sku;
var WxParse = require('../../../wxParse/wxParse.js');
var count = 1;
var index;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    list: [{
        title: "商品",
        img: "",
        id: 1
      },
      {
        title: "评价",
        img: "",
        id: 2
      },
      {
        title: "详情",
        img: "",
        id: 3
      }
    ],
    navId: 1,
    lunbo: [],
    pingjia: [],
    xiangqingimg: ["../../image/cuohao.png", "../../image/cuohao.png", "../../image/cuohao.png", "../../image/cuohao.png"],
    shop: true,
    evaluate: true,
    details: true,
    data: "",
    isguige: false,
    guigeid: 0,
    gwcjq: "",
    jgwcsl: 1,
    pjdata: '',
    jrorgm: "", //1加入购物车，2是立即购买
    indexid: -1,
    kefu: ""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    wx.setNavigationBarTitle({
      title: '牧鹤在线',
    })
    var that = this;
    wx.getStorage({
      key: 'config',
      success: function(res) {
        console.log(res)
        that.setData({
          kefu: res.data
        })
      },
      fail: function(res) {},
      complete: function(res) {},
    })
    that.setData({
      evaluate: false,
      details: false
    })
    console.log(options.id)
    id = options.id;
    wx.getStorage({
      key: 'token',
      success: function(res) {
        wx.request({
          url: app.url + '/api/goods/' + id,
          data: '',
          header: {
            'client-token': res.data
          },
          method: 'GET',
          dataType: 'json',
          responseType: 'text',
          success: function(res) {
            console.log(res)

            if (res.data.code == 0) {
              goodsid = res.data.data.id
              that.setData({
                lunbo: res.data.data.pics,
                data: res.data.data,
                gwcjq: res.data.data.price
              })
              console.log(res.data.data.desc)
              var aHrefHrefData = res.data.data.desc;
              console.log(aHrefHrefData)
              WxParse.wxParse('aHrefHrefData', 'html', aHrefHrefData, that);
            }
            console.log(that.data.data.props[0].values[0].title)
          },
          fail: function(res) {},
          complete: function(res) {},
        })
        wx.request({
          url: app.url + '/api/comment/paginate',
          data: {
            goods: id
          },
          header: {
            'client-token': res.data
          },
          method: 'GET',
          dataType: 'json',
          responseType: 'text',
          success: function(res) {
            console.log(res)
            if (res.data.code == 0) {

              for (let i in res.data.data.results){
                res.data.data.results[i].createdAt = res.data.data.results[i].createdAt.split('T')[0]
              }
              setTimeout(()=>{
                that.setData({
                  pjdata: res.data.data
                })
              },100)

            }
          },
          fail: function(res) {},
          complete: function(res) {},
        })
      },
      fail: function(res) {},
      complete: function(res) {},
    })


  },
  bodadh() {
    var that = this;
    wx.makePhoneCall({
      phoneNumber: that.data.kefu.serviceTel
    })
  },
  fenxiang() {

  },
  qbpj() {
    console.log("111")
    var that = this;
    that.setData({
      shop: false,
      evaluate: true,
      details: false,
      navId: 2
    })
  },
  // 选择导航栏
  selectNav(e) {
    var that = this;
    that.setData({
      navId: e.currentTarget.dataset.id
    })
    if (e.currentTarget.dataset.id == 1) {
      that.setData({
        shop: true,
        evaluate: false,
        details: false
      })
    } else if (e.currentTarget.dataset.id == 2) {
      that.setData({
        shop: false,
        evaluate: true,
        details: false,
      })
    } else if (e.currentTarget.dataset.id == 3) {
      that.setData({
        shop: false,
        evaluate: false,
        details: true,
      })
    }
  },
  // 加入购物车事件
  jrgwc() {
    var that = this;
    that.setData({
      isguige: true,
      jrorgm: 1
    })
  },
  ljgm() {
    var that = this;
    that.setData({
      isguige: true,
      jrorgm: 2
    })
  },
  // 选规格事件
  xgg(e) {
    var that = this;
    console.log(e.currentTarget.dataset)
    console.log(e.currentTarget.dataset.sku)
    sku = e.currentTarget.dataset.sku
    console.log("确认下单", that.data.data.skus[e.currentTarget.dataset.index].price)
    console.log("确认下单折扣", that.data.data.skus[e.currentTarget.dataset.index].discount)
    //  console.log(index)
    that.setData({
      gwcjq: that.data.data.skus[e.currentTarget.dataset.index].price,
    })
    console.log(e.currentTarget.dataset.index)
    console.log(index)
    if (e.currentTarget.dataset.index != index) {
      console.log(e.currentTarget.dataset.index + '111')
      that.setData({
        guigeid: that.data.data.skus[e.currentTarget.dataset.index].id,
        indexid: e.currentTarget.dataset.index
      })
    } else if (e.currentTarget.dataset.index == index) {
      // console.log
      if (that.data.indexid == -1) {
        that.setData({
          guigeid: that.data.data.skus[e.currentTarget.dataset.index].id,
          indexid: e.currentTarget.dataset.index
        })
      } else {
        that.setData({
          indexid: -1
        })
      }

    }
    index = e.currentTarget.dataset.index
    console.log(index)
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },
  gwcqd() {
    var that = this;
    if (that.data.guigeid == 0) {
      wx.showToast({
        title: '请选择规格',
        image: '/pages/image/cuohao.png',
        duration: 1000,
      })
    } else {
      console.log(goodsid)
      console.log(that.data.guigeid)
      wx.getStorage({
        key: 'token',
        success: function(res) {
          if (that.data.jrorgm == 1) {
            wx.request({
              url: app.url + '/api/cart-goods',
              data: {
                goods: goodsid,
                sku: that.data.guigeid,
                quantity: that.data.jgwcsl
              },
              header: {
                'client-token': res.data
              },
              method: 'POST',
              dataType: 'json',
              responseType: 'text',
              success: function(res) {
                console.log(res)
                if (res.data.code == 0) {
                  wx.showToast({
                    title: "加入购物车成功",
                    icon: '',
                    image: '',
                    duration: 1000,
                    mask: true,
                    success: function(res) {},
                    fail: function(res) {},
                    complete: function(res) {},
                  })
                  that.setData({
                    isguige: false
                  })
                }
              },
              fail: function(res) {},
              complete: function(res) {},
            })
          } else if (that.data.jrorgm == 2) {
            // console.log(sku)
            var orders = [{}]
            for (var i in orders) {
              orders[i].goods = goodsid
              orders[i].quantity = that.data.jgwcsl
              orders[i].sku = that.data.guigeid
            }

            console.log(orders)
            var goodsobj = orders
            console.log(goodsobj)
            app.globalData.goodsobj = goodsobj;
            wx.request({
              url: app.url + '/api/order/pre-create',
              data: {
                goods: goodsobj
              },
              header: {
                'client-token': res.data
              },
              method: 'POST',
              dataType: 'json',
              responseType: 'text',
              success: function(res) {
                console.log(res)
                var orders = res.data.data.orders
                if (res.data.code == 0) {
                  var data = Date.parse(new Date());
                  wx.setStorage({
                    key: 'orders',
                    data: orders,
                    success: function(res) {},
                    fail: function(res) {},
                    complete: function(res) {},
                  })
                  wx.navigateTo({
                    url: '/pages/main/confirmAnOrder/confirmAnOrder?' + data,
                    success: function(res) {

                    },
                    fail: function(res) {},
                    complete: function(res) {},
                  })
                }
              },
              fail: function(res) {},
              complete: function(res) {},
            })

            // wx.request({
            //   url: app.url + '/api/payment',
            //   data: {
            //     orders: orders,
            //     payment:'weixin:wxapp'
            //   },
            //   header: { 'client-token': res.data },
            //   method: 'POST',
            //   dataType: 'json',
            //   responseType: 'text',
            //   success: function (res) {
            //     console.log(res)
            //     if (res.data.code == 0) {
            //       wx.showToast({
            //         title: "加入购物车成功",
            //         icon: '',
            //         image: '',
            //         duration: 2000,
            //         mask: true,
            //         success: function (res) { },
            //         fail: function (res) { },
            //         complete: function (res) { },
            //       })
            //     }
            //   },
            //   fail: function (res) { },
            //   complete: function (res) { },
            // })
          }

        },
        fail: function(res) {},
        complete: function(res) {},
      })
    }
  },
  //购物车数量减少事件
  jiangwcsl() {
    var that = this;
    if (that.data.jgwcsl == 1) {
      that.setData({
        isguige: false
      })
    } else if (that.data.jgwcsl > 1) {
      that.setData({
        jgwcsl: that.data.jgwcsl - 1
      })
    }

  },
  // 购物车数量增加事件
  jiagwcsl() {
    var that = this;
    that.setData({
      jgwcsl: that.data.jgwcsl + 1
    })
  },
  // 取消加购物车事件
  qxjgwc() {
    var that = this;
    that.setData({
      isguige: false
    })
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    //  console.log("456")
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})