// pages/product/chanpin/chanpin.js
var app = getApp();
var page = 1;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    list: [{
      title: "鸡预混料",
      id: 0
    }, {
      title: "猪预混料",
      id: 1
    }, {
      title: "添加剂",
      id: 2
    }],
    id: 0,
    list2: [],
    flid:"",
    ssgjz:""
  },
  // daohang(e) {
  //   var that = this;
  //   console.log(e.currentTarget.dataset.id)
  //   that.setData({
      
  //   })
  // },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    wx.setNavigationBarTitle({
      title: '牧鹤在线',
    })
    var that = this;
    if (options.gjz==undefined){
      wx.request({
        url: app.url + '/api/goods/paginate',
        data: {
          _page:page
        },
        header: {},
        method: 'GET',
        dataType: 'json',
        responseType: 'text',
        success: function (res) {
          console.log(res)
          console.log(res.data.data.results)
          if (res.data.code == 0) {
            that.setData({
              list2: res.data.data.results
            })
          }
        },
        fail: function (res) { },
        complete: function (res) { },
      })
    }else{
      wx.request({
        url: app.url + '/api/goods/paginate',
        data: {
          _search: that.data.ssgjz,
          _page: page
        },
        header: {},
        method: 'GET',
        dataType: 'json',
        responseType: 'text',
        success: function (res) {
          console.log(res)
          console.log(res.data.data.results)
          // if (res.data.code == 0) {
          //   that.setData({
          //     list2: res.data.data.results
          //   })
          // }
        },
        fail: function (res) { },
        complete: function (res) { },
      })
    }
   
    wx.request({
      url: app.url +'/api/category',
      data: '',
      header: {},
      method: 'GET',
      dataType: 'json',
      responseType: 'text',
      success: function(res) {
        if(res.data.code==0){
          that.setData({
            list:res.data.data
          })
        }
      },
      fail: function(res) {},
      complete: function(res) {},
    })
    console.log(app.globalData.cpnavidk)
    setTimeout(()=>{
      if (app.globalData.cpnavid != -1) {
        console.log(that.data.list)
        that.setData({
          flid: that.data.list[app.globalData.cpnavid].id
        })
        // console.log()
        console.log(that.data.list[app.globalData.cpnavid].id)
        console.log(that.data.flid)
        wx.request({
          url: app.url + '/api/goods/paginate?cats=' + that.data.flid,
          data: {
            _page: page
          },
          header: {},
          method: 'GET',
          dataType: 'json',
          responseType: 'text',
          success: function (res) {
            console.log(res)
            console.log(res.data.data.results)
            if (res.data.code == 0) {
              that.setData({
                list2: res.data.data.results
              })
            }
          },
          fail: function (res) { },
          complete: function (res) { },
        })
      } else {
        wx.request({
          url: app.url + '/api/goods/paginate',
          data: {
            _search: that.data.ssgjz,
            _page: page
          },
          header: {},
          method: 'GET',
          dataType: 'json',
          responseType: 'text',
          success: function (res) {
            console.log(res)
            console.log(res.data.data.results)
            // if (res.data.code == 0) {
            //   that.setData({
            //     list2: res.data.data.results
            //   })
            // }
          },
          fail: function (res) { },
          complete: function (res) { },
        })
      }
    },500)
    
  },
// 选择展示分类页面
  daohang(e){
    var that = this;
    console.log(e.currentTarget.dataset.idid)
    console.log(e.currentTarget.dataset.id)
    that.setData({
      flid: e.currentTarget.dataset.idid,
      id: e.currentTarget.dataset.id
    })
    console.log(that.data.flid)
    wx.request({
      url: app.url + '/api/goods/paginate?cats='+that.data.flid,
      data: {
        _page: page
      },
      header: {},
      method: 'GET',
      dataType: 'json',
      responseType: 'text',
      success: function (res) {
        console.log(res)
        console.log(res.data.data.results)
        if (res.data.code == 0) {
          that.setData({
            list2: res.data.data.results
          })
        }
      },
      fail: function (res) { },
      complete: function (res) { },
    })
  },
  tzxq(e){
    console.log(e.currentTarget.dataset.id)
    wx.navigateTo({
      url: '/pages/product/productDetails/productDetails?id=' + e.currentTarget.dataset.id,
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) { },
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    var that = this;
    console.log(app.globalData.ssgjz)
    if (app.globalData.ssgjz) {
      that.setData({
        ssgjz: app.globalData.ssgjz
      })
    }
    console.log(app.globalData.cpnavid)
    if (app.globalData.cpnavid) {
      that.setData({
        id: app.globalData.cpnavid
      })
    }
    console.log(that.data.ssgjz)
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {
    page++;
    console.log(page)
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})