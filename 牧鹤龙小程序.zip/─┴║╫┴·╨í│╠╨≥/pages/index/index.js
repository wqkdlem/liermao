//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    motto: 'Hello World',
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
  },
  //事件处理函数
  bindViewTap: function() {
    var id;
    // wx.navigateTo({
    //   url: '/pages/homepage/login/login'
    // })
    wx.login({
      success: function(res) {
        console.log(res)
        wx.request({
          url: app.url + '/api/client',
          data: {
            wxCode: res.code,
            platform: "wxapp"
          },
          header: {},
          method: 'POST',
          dataType: 'json',
          responseType: 'text',
          success: function(res) {
            console.log(res.data.data.token)
            console.log(res)
            console.log(res.data.data.config)
            app.globalData.token=res.data.data.token;
            app.globalData.config=res.data.data.config;
            if (res.data.code == 0) {
              if (res.data.data.user){
                wx.setStorage({
                  key: 'phone',
                  data: 'res.data.data.user.tel',
                  success: function(res) {},
                  fail: function(res) {},
                  complete: function(res) {},
                })
                wx.switchTab({
                  url: '/pages/homepage/home/home',
                  success: function(res) {},
                  fail: function(res) {},
                  complete: function(res) {},
                })
              }else{
                wx.navigateTo({
                  url: '/pages/homepage/login/login',
                  success: function(res) {},
                  fail: function(res) {},
                  complete: function(res) {},
                })
              }
              
              wx.setStorage({
                key: 'config',
                data: res.data.data.config,
                success: function(res) {},
                fail: function(res) {},
                complete: function(res) {},
              })
              id = res.data.data.id
              wx.setStorage({
                key: 'token',
                data: res.data.data.token,
                success: function(res) {
                },
                fail: function(res) {},
                complete: function(res) {},
              })
              wx.getUserInfo({
                success: function (aa) {
                  console.log(123)
                  console.log(aa, '用户信息')
                  var xx = aa;
                  app.globalData.xx = xx
                  wx.setStorage({
                    key: 'avatarUrl',
                    data: xx.userInfo.avatarUrl
                  })
                  wx.setStorage({
                    key: 'nickName',
                    data: xx.userInfo.nickName
                  })
                 

                },
                fail: function (res) {
                  console.log(res)
                },
                complete: function (res) {
                  console.log(res)
                },
              })
              wx.setStorage({
                key: 'gywm',
                data: res.data.data.config,
                success: function(res) {},
                fail: function(res) {},
                complete: function(res) {},
              })
            }

          },
          fail: function(res) {},
          complete: function(res) {},
        })
       
      },
      fail: function(res) {},
      complete: function(res) {},
    })
  },
  onLoad: function(aaa) {
    wx.setNavigationBarTitle({
      title: '牧鹤在线',
    })
    var id;
    wx.login({
      success: function (res) {
        console.log('after wx.login',res)
        wx.request({
          url: app.url + '/api/client',
          data: {
            wxCode: res.code,
            platform: "wxapp"
          },
          header: {},
          method: 'POST',
          dataType: 'json',
          responseType: 'text',
          success: function (res) {
            console.log('after reg client',res.data)
            console.log(res)
            console.log(res.data.data.config)
            app.globalData.token = res.data.data.token;
            app.globalData.config = res.data.data.config;
            if (res.data.code !== 0) return;
            
            if (res.data.data.user) {
              wx.setStorage({
                key: 'phone',
                data: 'res.data.data.user.tel',
                success: function (res) { },
                fail: function (res) { },
                complete: function (res) { },
              })
              wx.switchTab({
                url: '/pages/homepage/home/home',
                success: function (res) { },
                fail: function (res) { },
                complete: function (res) { },
              })
            } else {
              // wx.navigateTo({
              //   url: '/pages/homepage/login/login',
              //   success: function (res) { },
              //   fail: function (res) { },
              //   complete: function (res) { },
              // })
            }

            wx.setStorage({
              key: 'config',
              data: res.data.data.config,
              success: function (res) { },
              fail: function (res) { },
              complete: function (res) { },
            })
            id = res.data.data.id
            wx.setStorage({
              key: 'token',
              data: res.data.data.token,
              success: function (res) {
              },
              fail: function (res) { },
              complete: function (res) { },
            })
            wx.getUserInfo({
              success: function (aa) {
                console.log(123)
                console.log(aa, '用户信息')
                var xx = aa;
                app.globalData.xx = xx
                wx.setStorage({
                  key: 'avatarUrl',
                  data: xx.userInfo.avatarUrl
                })
                wx.setStorage({
                  key: 'nickName',
                  data: xx.userInfo.nickName
                })


              },
              fail: function (res) {
                console.log(res)
              },
              complete: function (res) {
                console.log(res)
              },
            })
            wx.setStorage({
              key: 'gywm',
              data: res.data.data.config,
              success: function (res) { },
              fail: function (res) { },
              complete: function (res) { },
            })

          },
          fail: function (res) { },
          complete: function (res) { },
        })

      },
      fail: function (res) { },
      complete: function (res) { },
    })
    app.globalData.jlj=0;
    wx.setStorage({
      key: 'scene',
      data: aaa.scene,
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    })
    if (aaa.scene) {
      console.log(aaa)
      if (aaa.scene[0] == 'p') {
        wx.getStorage({
          key: 'token',
          success: function(res) {
            wx.request({
              url: app.url + '/api/user/bind-promoter',
              data: {
                promoter: aaa.scene.split('p-')[1]
              },
              header: {
                'client-token': res.data
              },
              method: 'GET',
              dataType: 'json',
              responseType: 'text',
              success: function(res) {
                wx.getStorage({
                  key: 'token',
                  success: function (res) {
                    wx.navigateTo({
                      url: '/pages/homepage/login/login',
                      success: function (res) { },
                      fail: function (res) { },
                      complete: function (res) { },
                    })
                  },
                  fail: function (res) { },
                  complete: function (res) { },
                })
              },
              fail: function(res) {},
              complete: function(res) {},
            })
          },
          fail: function(res) {},
          complete: function(res) {},
        })
      } else if (aaa.scene[0] == 'a') {
        wx.getStorage({
          key: 'token',
          success: function(res) {
            wx.request({
              url: app.url + '/api/user/bind-promoter',
              data: {
                agency: aaa.scene.split('a-')[1]
              },
              header: {
                'client-token': res.data
              },
              method: 'GET',
              dataType: 'json',
              responseType: 'text',
              success: function(res) {
                wx.getStorage({
                  key: 'token',
                  success: function (res) {
                    wx.navigateTo({
                      url: '/pages/homepage/login/login',
                      success: function (res) { },
                      fail: function (res) { },
                      complete: function (res) { },
                    })
                  },
                  fail: function (res) { },
                  complete: function (res) { },
                })
              },
              fail: function(res) {},
              complete: function(res) {},
            })
          },
          fail: function(res) {},
          complete: function(res) {},
        })
      }
    } else {
      wx.getStorage({
        key: 'token',
        success: function(res) {
          wx.login({
            success: function (res) {
              console.log(res)
              wx.request({
                url: app.url + '/api/client',
                data: {
                  wxCode: res.code,
                  platform: "wxapp"
                },
                header: {},
                method: 'POST',
                dataType: 'json',
                responseType: 'text',
                success: function (res) {
                  console.log(res.data.data.token)
                  console.log(res)
                  console.log(res.data.data.config)
                  app.globalData.token = res.data.data.token;
                  app.globalData.config = res.data.data.config;
                  if (res.data.code == 0) {
                    console.log(res)
                    // if (res.data.data.user) {
                    //   wx.setStorage({
                    //     key: 'phone',
                    //     data: 'res.data.data.user.tel',
                    //     success: function (res) { },
                    //     fail: function (res) { },
                    //     complete: function (res) { },
                    //   })
                    //   wx.switchTab({
                    //     url: '/pages/homepage/home/home',
                    //     success: function (res) { },
                    //     fail: function (res) { },
                    //     complete: function (res) { },
                    //   })
                    // } else {
                    //   wx.navigateTo({
                    //     url: '/pages/homepage/login/login',
                    //     success: function (res) { },
                    //     fail: function (res) { },
                    //     complete: function (res) { },
                    //   })
                    // }
                    wx.getUserInfo({
                      success: function (aa) {
                        console.log(123)
                        console.log(aa, '用户信息')
                        var xx = aa;
                        app.globalData.xx = xx
                        wx.setStorage({
                          key: 'avatarUrl',
                          data: xx.userInfo.avatarUrl
                        })
                        wx.setStorage({
                          key: 'nickName',
                          data: xx.userInfo.nickName
                        })


                      },
                      fail: function (res) {
                        console.log(res)
                      },
                      complete: function (res) {
                        console.log(res)
                      },
                    })
                    wx.setStorage({
                      key: 'config',
                      data: res.data.data.config,
                      success: function (res) { },
                      fail: function (res) { },
                      complete: function (res) { },
                    })
                    id = res.data.data.id
                    wx.setStorage({
                      key: 'token',
                      data: res.data.data.token,
                      success: function (res) {
                      },
                      fail: function (res) { },
                      complete: function (res) { },
                    })
                    
                    wx.setStorage({
                      key: 'gywm',
                      data: res.data.data.config,
                      success: function (res) { },
                      fail: function (res) { },
                      complete: function (res) { },
                    })
                  }

                },
                fail: function (res) { },
                complete: function (res) { },
              })

            },
            fail: function (res) { },
            complete: function (res) { },
          })
          // wx.getStorage({
          //   key: 'phone',
          //   success: function (res) {
          //     console.log(res, "有手机号了")
          //     wx.switchTab({
          //       url: '/pages/homepage/home/home'
          //     })
          //   },
          //   fail: function (res) {
          //     wx.navigateTo({
          //       url: '/pages/homepage/login/login',
          //       success: function (res) { },
          //       fail: function (res) { },
          //       complete: function (res) { },
          //     })
          //   },
          //   complete: function (res) { },
          // })
          
        },
        fail: function(res) {},
        complete: function(res) {},
      })
    }

    // if (app.globalData.userInfo) {
    //   this.setData({
    //     userInfo: app.globalData.userInfo,
    //     hasUserInfo: true
    //   })
    // } else if (this.data.canIUse) {
    //   // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
    //   // 所以此处加入 callback 以防止这种情况
    //   app.userInfoReadyCallback = res => {
    //     this.setData({
    //       userInfo: res.userInfo,
    //       hasUserInfo: true
    //     })
    //   }
    // } else {
    //   // 在没有 open-type=getUserInfo 版本的兼容处理
    //   wx.getUserInfo({
    //     success: res => {
    //       app.globalData.userInfo = res.userInfo
    //       this.setData({
    //         userInfo: res.userInfo,
    //         hasUserInfo: true
    //       })
    //     }
    //   })
    // }
  },
  getUserInfo: function(e) {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  }
})