// pages/homepage/login/login.js
var app = getApp()
// var jlj;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    count: 0,
    isgouxuan: 0,
    pdphone: "获取验证码",
    phone: "",
    yzm: '',
    token: '',
    hqyzm: true,
    jlj: "",
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    wx.setNavigationBarTitle({
      title: '牧鹤在线',
    })
    // console.log(options.jlj)
    // jlj = options.jlj;
    var xx = app.globalData.xx;
    console.log(xx)
    wx.getStorage({
      key: 'phone',
      success: function(res) {
        console.log(res, "有手机号了")
        wx.switchTab({
          url: '/pages/homepage/home/home'
        })
      },
      fail: function(res) {
        console.log(res, "mei有手机号了")
      },
      complete: function(res) {},
    })
    // if (app.globalData.phone){
    //   wx.switchTab({
    //       url: '/pages/homepage/home/home'
    //     })
    // }
    
  },
  // 获取输入的手机号事件
  hqphone(e) {
    // console.log(e.detail.value)
    this.setData({
      phone: e.detail.value
    })
  },
  hqsryzm(e) {
    // console.log(e.detail.value)
    this.setData({
      yzm: e.detail.value
    })
  },
  // 判断手机号并且获取验证码事件
  pdsjh() {
    var that = this;
    var myreg = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1})|(17[0-9]{1}))+\d{8})$/;
    var nsecond = 60;
    that.setData({
      hqyzm: false
    })
    if (that.data.phone.length == 0) {
      wx.showToast({
        title: '请输入手机号！',
        image: '../../image/cuohao.png',
        duration: 1500
      })
      return false;
    } else if (that.data.phone.length != 11) {
      wx.showToast({
        title: '手机号长度有误！',
        image: '../../image/cuohao.png',
        duration: 1500
      })
      return false;
    } else if (!myreg.test(that.data.phone)) {
      wx.showToast({
        title: '手机号有误！',
        image: '../../image/cuohao.png',
      })
      return false;
    } else {
      wx.getStorage({
        key: 'token',
        success: function(res) {
          wx.request({
            url: app.url + '/api/captcha/send',
            data: {
              to: that.data.phone,
              id: 'login'
            },
            header: {
              'client-token': res.data
            },
            method: 'POST',
            dataType: 'json',
            responseType: 'text',
            success: function(res) {
              console.log(res)
              if (res.data.code == 0) {
                that.setData({
                  pdphone: 90
                })
                var appCount = setInterval(function() {
                  that.setData({
                    pdphone: that.data.pdphone - 1
                  })
                  if (that.data.pdphone < 1) {
                    clearInterval(appCount);
                    //取消指定的setInterval函数将要执行的代码 
                    that.setData({
                      pdphone: '获取验证码',
                      hqyzm: true
                    })
                  }
                }, 1000)
              }

            },
            fail: function(res) {},
            complete: function(res) {},
          })
        },
        fail: function(res) {},
        complete: function(res) {},
      })

    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  // 是否同意用户协议时间
  isgouxuan() {
    var that = this;
    that.setData({
      count: that.data.count + 1,
    })
    that.setData({
      isgouxuan: that.data.count % 2,
    })
    console.log(that.data.count, that.data.isgouxuan)
    // if (that.data.isgouxua == 1) {

    // }
  },
  // 跳转用户协议
  yhxy() {
    wx.navigateTo({
      url: '/pages/homepage/zcxy/information-s',
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    })
  },
  login() {
    var xx = app.globalData.xx;
    console.log(xx)
    var that = this;
    wx.getStorage({
      key: 'token',
      success: function(res) {
        console.log(res)
        that.setData({
          token: res.data
        })
        console.log(that.data.token)
        if (that.data.isgouxuan == 1) {
          console.log("123")
          wx.showToast({
            title: '您未同意用户协议',
            image: '../../image/cuohao.png',
            icon: 2000
          })
        } else if (that.data.phone.length == 0) {
          wx.showToast({
            title: '您未输入手机号',
            image: '../../image/cuohao.png',
            icon: 2000
          })
        } else if (that.data.yzm.length == 0) {
          wx.showToast({
            title: '您未输入验证码',
            image: '../../image/cuohao.png',
            icon: 2000
          })
        } else {
          console.log(that.data.token)
          wx.getStorage({
            key: 'token',
            success: function(res) {
              
              wx.request({
                url: app.url + '/api/user/login',
                data: {
                  tel: that.data.phone,
                  captcha: that.data.yzm,
                  avatar: xx.userInfo.avatarUrl,
                  displayName: xx.userInfo.nickName,
                },
                header: {
                  'client-token': that.data.token
                },
                method: 'POST',
                dataType: 'json',
                responseType: 'text',
                success: function(res) {
                  console.log(res)
                  console.log("123")
                  if (res.data.code == 0) {
                    console.log(res.data.data.registerAward)
                    app.globalData.jlj = res.data.data.registerAward
                    console.log(app.globalData.jlj)
                    wx.showToast({
                      title: '登录成功',
                      image: '',
                      duration: 2000,
                    })
                    // wx.getStorage({
                    //   key: 'token',
                    //   success: function (res) {
                    //     console.log('123')
                    //     console.log(res.data, "token")
                    //     wx.request({
                    //       url: app.url + '/api/user/info',
                    //       data: {
                    //         avatar: xx.userInfo.avatarUrl,
                    //         displayName: xx.userInfo.nickName,
                    //         id: id
                    //       },
                    //       header: {
                    //         'client-token': res.data
                    //       },
                    //       method: 'PUT',
                    //       dataType: 'json',
                    //       responseType: 'text',
                    //       success: function (res) {
                    //         console.log(res)
                    //         console.log(xx.userInfo.avatarUrl, '头像')
                    //         console.log(xx.userInfo.nickName, '昵称')

                    //       },
                    //       fail: function (res) { },
                    //       complete: function (res) { },
                    //     })
                    //   },
                    //   fail: function (res) { },
                    //   complete: function (res) { },
                    // })
                    wx.setStorage({
                      key: 'phone',
                      data: that.data.phone,
                      success: function(res) {},
                      fail: function(res) {},
                      complete: function(res) {},
                    })
                    wx.switchTab({
                      url: '/pages/homepage/home/home'
                    })
                    app
                  }

                },
                fail: function(res) {},
                complete: function(res) {},
              })
            },
            fail: function(res) {},
            complete: function(res) {},
          })


        }
      },
      fail: function(res) {},
      complete: function(res) {},
    })
    console.log(that.data.isgouxuan)

  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})