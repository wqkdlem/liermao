//index.js
//获取应用实例
const app = getApp()
var ssgjz;
var ggid;
var scene;
app.globalData.cpnavid=-1;
Page({
  data: {
    lunbo:[
      { img: "../../image/cuohao.png" },
      { img: "../../image/cuohao.png" },
      { img: "../../image/cuohao.png" },
      { img: "../../image/cuohao.png" },
      { img: "../../image/cuohao.png" },
      { img: "../../image/cuohao.png" },
    ],
    slist:[],
    motto: 'Hello World',
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    ggcount:"",
    fenlei:'',
    jlj:""
  },
  onLoad: function () {
    var that = this;
    wx.setNavigationBarTitle({
      title: '牧鹤在线',
    })
    console.log(app.globalData.jlj)
    app.globalData.balance = app.globalData.jlj
     that.setData({
       jlj: app.globalData.jlj
     })
    wx.getStorage({
      key: 'token',
      success: function(res) {
        wx.request({
          url: app.url +'/api/goods/paginate?recommend=true',
          data: '',
          header: { 'client-token': res.data},
          method: 'GET',
          dataType: 'json',
          responseType: 'text',
          success: function(res) {
            console.log(res)
            if(res.data.code==0){
              that.setData({
                slist: res.data.data.results
              })
            } 
          },
          fail: function(res) {},
          complete: function(res) {},
        })
        wx.request({
          url: app.url +'/api/banner',
          data: '',
          header: { 'client-token': res.data},
          method: 'GET',
          dataType: 'json',
          responseType: 'text',
          success: function(res) {
            console.log(res)
            that.setData({
              lunbo:res.data.data
            })
          },
          fail: function(res) {},
          complete: function(res) {},
        })
        wx.request({
          url: app.url + '/api/post/paginate',
          data: '',
          header: { 'client-token': res.data},
          method: 'GET',
          dataType: 'json',
          responseType: 'text',
          success: function (res) {
            console.log(res)
            console.log(res.data.data.results)
            console.log(res.data.code)
            if (res.data.code == 0) {
              that.setData({
                ggcount: res.data.data.results[0].title
              })
              ggid = res.data.data.results[0].id
            }
            // console.log(that.data.list)
          },
          fail: function (res) { },
          complete: function (res) { },
        })
        wx.request({
          url: app.url + '/api/category',
          data: '',
          header: { 'client-token': res.data},
          method: 'GET',
          dataType: 'json',
          responseType: 'text',
          success: function (res) {
            if (res.data.code == 0) {
              that.setData({
                fenlei: res.data.data
              })
            }
          },
          fail: function (res) { },
          complete: function (res) { },
        })
      },
      fail: function(res) {},
      complete: function(res) {},
    })
    // 获取用户信息
    wx.getStorage({
      key: 'token',
      success: function (res) {
        wx.request({
          url: app.url + '/api/user/info',
          data: '',
          header: {
            'client-token': res.data
          },
          method: 'GET',
          dataType: 'json',
          responseType: 'text',
          success: function (res) {
            wx.getStorage({
              key: 'scene',
              success: function(res) {
                scene = res.data
              },
              fail: function(res) {},
              complete: function(res) {},
            })
            console.log(res)
           if(res.data.code==0){
             if (res.data.data.promoter){
              //  已经绑定过
               if (scene.split('a-')[1] != res.data.data.promoter){
                 wx.showToast({
                   title: '您已经绑定过',
                   icon: '',
                   image: '',
                   duration: 1000,
                   mask: true,
                   success: function(res) {},
                   fail: function(res) {},
                   complete: function(res) {},
                 })
               }
               
             }
             else if (res.data.data.agency){
               //  已经绑定过
               if (scene.split('p-')[1] != res.data.data.agency) {
                 wx.showToast({
                   title: '您已经绑定过',
                   icon: '',
                   image: '',
                   duration: 1000,
                   mask: true,
                   success: function (res) { },
                   fail: function (res) { },
                   complete: function (res) { },
                 })
               }
             }
             else{
              // 
                // wx.getStorage({
                //   key: 'scene',
                //   success: function(res) {
                    if (scene){
                      console.log(scene)
                      if (scene[0] == 'p') {
                        wx.getStorage({
                          key: 'token',
                          success: function (res) {
                            wx.request({
                              url: app.url + '/api/user/bind-promoter',
                              data: {
                                promoter: scene.split('p-')[1]
                              },
                              header: {
                                'client-token': res.data
                              },
                              method: 'GET',
                              dataType: 'json',
                              responseType: 'text',
                              success: function (res) { },
                              fail: function (res) { },
                              complete: function (res) { },
                            })
                          },
                          fail: function (res) { },
                          complete: function (res) { },
                        })
                      } else if (scene[0] == 'a') {
                        wx.getStorage({
                          key: 'token',
                          success: function (res) {
                            wx.request({
                              url: app.url + '/api/user/bind-promoter',
                              data: {
                                agency:scene.split('a-')[1]
                              },
                              header: {
                                'client-token': res.data
                              },
                              method: 'GET',
                              dataType: 'json',
                              responseType: 'text',
                              success: function (res) { },
                              fail: function (res) { },
                              complete: function (res) { },
                            })
                          },
                          fail: function (res) { },
                          complete: function (res) { },
                        })
                      }
                    }
                  // },
                  // fail: function(res) {},
                  // complete: function(res) {},
                // })
              // 
             }
           }
          },
          fail: function (res) { },
          complete: function (res) { },
        })
      },
      fail: function (res) { },
      complete: function (res) { },
    })
  },
  tzxq(e){
    var that = this;
    wx.navigateTo({
      url: '/pages/product/productDetails/productDetails?id=' + e.currentTarget.dataset.id ,
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    })
  },
  // 获取搜索关键字
  hqssgjz(e){
    var that = this;
    console.log(e)
    console.log(e.detail.value)
      ssgjz=e.detail.value
    app.globalData.ssgjz = ssgjz;
  },
  // 展示搜索列表
  zssslb(){
    var that = this;
    console.log(ssgjz)
    if (ssgjz==undefined){
      wx.showToast({
        title: '您还未输入搜索内容',
        icon: '',
        image: '/pages/image/cuohao.png',
        duration: 1000,
        mask: true,
        success: function(res) {},
        fail: function(res) {},
        complete: function(res) {},
      })
    }else{
      wx.switchTab({
        url: '/pages/product/chanpin/chanpin',
        success: function (res) { },
        fail: function (res) { },
        complete: function (res) { },
      })
    }
  
  },
  // 跳转公告详情
  tzggxq(){
    wx.navigateTo({
      url: '/pages/information/information-s/information-s?id=' + ggid,
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) { },
    })
  },
  jptjgd(){
    wx.switchTab({
      url: '/pages/product/chanpin/chanpin',
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) { },
    })
  },
  tzdcp(e){
    console.log(e.currentTarget.dataset.index)
    app.globalData.cpnavid = e.currentTarget.dataset.index;
    var id = e.currentTarget.dataset.index;
   wx.switchTab({
     url: '/pages/product/chanpin/chanpin',
     success: function(res) {},
     fail: function(res) {},
     complete: function(res) {},
   })
  },
  //轮播图
  lunbotz(e){
    var that = this;
    console.log(e.currentTarget.dataset.sp_list)
    var list = e.currentTarget.dataset.sp_list;
    var id;
    if (list.action=='post'){
      id = list.post
      wx.navigateTo({
        url: '/pages/information/information-s/information-s?id=' + id,
        success: function (res) { },
        fail: function (res) { },
        complete: function (res) { },
      })
    } else if (list.action == 'goods-list'){
      wx.switchTab({
        url: 'pages/product/chanpin/chanpin',
        success: function(res) {},
        fail: function(res) {},
        complete: function(res) {},
      })
    } else if (list.action =='goods'){
      id = list.goods
      wx.navigateTo({
        url: '/pages/product/productDetails/productDetails?id=' + id,
        success: function (res) { },
        fail: function (res) { },
        complete: function (res) { },
      })
    }
    // if()
  },
  ljck() {
    var that = this;
    var that = this;
    that.setData({
      jlj: 0
    })   
    wx.navigateTo({
      url: '/pages/main/favorable/favorable?ljj='+that.data.jlj,
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) { },
    })
  },
  hdsy() {
    var that = this;
      that.setData({
        jlj:0
      })   
      },
})