// pages/information/information/information.js
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    list: []
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this;
    wx.setNavigationBarTitle({
      title: '资讯',
    })
    wx.getStorage({
      key: 'token',
      success: function(res) {
        wx.request({
          url: app.url + '/api/post/paginate',
          data: '',
          header: { 'client-token': res.data },
          method: 'GET',
          dataType: 'json',
          responseType: 'text',
          success: function (res) {
            console.log(res)
            console.log(res.data.data.results)
            console.log(res.data.code)
            if (res.data.code == 0) {
              for (var i in res.data.data.results){
                console.log(res.data.data.results[i].createdAt)
                console.log(res.data.data.results[i].createdAt.split('T')[0])
                console.log(res.data.data.results[i].createdAt.split('T')[1].split(':')[0])
                console.log(res.data.data.results[i].createdAt.split(':')[1])
                res.data.data.results[i].createdAt = res.data.data.results[i].createdAt.split('T')[0] +'  '+ res.data.data.results[i].createdAt.split('T')[1].split(':')[0] +':'+ res.data.data.results[i].createdAt.split(':')[1]
                console.log(res.data.data.results[i].createdAt)
              }
              setTimeout(()=>{
                that.setData({
                  list: res.data.data.results
                })
                console.log('咨询id',that.data.list)
              },100)
              
              
            }
          },
          fail: function (res) { },
          complete: function (res) { },
        })
      },
      fail: function(res) {},
      complete: function(res) {},
    })
    
  },
  // 跳转资讯详情事件
  tzxq(e) {
    console.log('咨询id',e.currentTarget.dataset,e.currentTarget.dataset.id)
    let id = e.currentTarget.dataset.id
    console.log('咨询id',id,'/pages/information/information-s/information-s?id='+id)
    wx.navigateTo({
      url: '/pages/information/information-s/information-s?id='+id,
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})