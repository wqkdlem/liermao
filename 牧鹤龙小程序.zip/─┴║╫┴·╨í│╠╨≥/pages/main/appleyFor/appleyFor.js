// pages/main/appleyFor/appleyFor.js
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    nickName:"",
    phone:"",
    address:"",
    count:"",
    phone1:""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.setNavigationBarTitle({
      title: '牧鹤在线',
    })
    var that = this;
    wx.getStorage({
      key: 'config',
      success: function (res) {
        console.log(res)
        that.setData({
          phone1: res.data.serviceTel
        })
        console.log(that.data.phone1)
      },
      fail: function (res) { },
      complete: function (res) { },
    })
   console.log(that.data.phone)
  },
  bddh(){
    wx.makePhoneCall({
      phoneNumber: this.data.phone,
    })
  },
  // 获取姓名事件
  hqxm(e){
    var that = this;
    console.log(e.detail.cursor)
    console.log(e.detail.value)
    that.setData({
      nickName: e.detail.value
    })
  },
  // 获取电话
  hqdh(e) {
    var that = this;
    console.log(e.detail.cursor)
    console.log(e.detail.value)
    that.setData({
      phone: e.detail.value
    })
  },
  // 获取位置
  hqdz(e) {
    var that = this;
    console.log(e.detail.cursor)
    console.log(e.detail.value)
    that.setData({
      address: e.detail.value
    })
  },
  //获取描述内容
  hqmsnr(e) {
    var that = this;
    console.log(e.detail.cursor)
    console.log(e.detail.value)
    that.setData({
      count: e.detail.value
    })
  },
  tjsqdls(){
    var that = this;
    if (that.data.nickName.length==0){
      wx.showToast({
        title: '请输入用户名',
        icon: '',
        image: '/pages/image/cuohao.png',
        duration: 1000,
      })
    } else if (that.data.phone.length == 0) {
      wx.showToast({
        title: '请输入联系方式',
        icon: '',
        image: '/pages/image/cuohao.png',
        duration: 1000,
      })
    } else if (that.data.address.length == 0) {
      wx.showToast({
        title: '请输入地址',
        icon: '',
        image: '/pages/image/cuohao.png',
        duration: 1000,
      })
    }else{
      wx.getStorage({
        key: 'token',
        success: function (res) {
          wx.request({
            url: app.url + '/api/agency-apply',
            data: {
              tel: that.data.phone,
              name: that.data.nickName,
              address: that.data.address,
              desc: that.data.count
            },
            header: { 'client-token': res.data },
            method: 'POST',
            dataType: 'json',
            responseType: 'text',
            success: function (res) { 
              console.log(res)
              if(res.data.code==0){
                wx.showToast({
                  title: '申请成功',
                  icon: '',
                  image: '',
                  duration: 1000,
                  mask: true,
                  success: function(res) {
                   wx.setStorage({
                     key: 'sql',
                     data:"申请了",
                     success: function(res) {},
                     fail: function(res) {},
                     complete: function(res) {},
                   })
                  },
                  fail: function(res) {},
                  complete: function(res) {},
                })
                wx.switchTab({
                  url: '/pages/main/main/main',
                  success: function (res) { },
                  fail: function (res) { },
                  complete: function (res) { },
                })
              }
            },
            fail: function (res) { },
            complete: function (res) { },
          })
        },
        fail: function (res) { },
        complete: function (res) { },
      })
    }
    

  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})