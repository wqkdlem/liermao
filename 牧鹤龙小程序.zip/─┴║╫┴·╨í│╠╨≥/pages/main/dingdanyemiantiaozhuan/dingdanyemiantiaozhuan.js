// pages/main/confirmAnOrder/confirmAnOrder.js
var navid;
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    data: "",
    navid: ""
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    wx.setNavigationBarTitle({
      title: '牧鹤在线',
    })
    console.log(options.id)
    navid = options.id;
    var that = this;
    console.log(app.globalData.ddlb)
    // for (var i in app.globalData.ddlb.results) {
    console.log(app.globalData.ddlb.createdAt)
    console.log(app.globalData.ddlb.createdAt.split('T')[0])
    console.log(app.globalData.ddlb.createdAt.split('T')[1].split(':')[0])
    console.log(app.globalData.ddlb.createdAt.split(':')[1])
    app.globalData.ddlb.createdAt = app.globalData.ddlb.createdAt.split('T')[0] + '  ' + app.globalData.ddlb.createdAt.split('T')[1].split(':')[0] + ':' + app.globalData.ddlb.createdAt.split(':')[1]
    console.log(app.globalData.ddlb.createdAt)
    // }
    setTimeout(() => {
      that.setData({
        data: app.globalData.ddlb,
        navid: options.id
      })
      console.log('支付订单', that.data.data)
    }, 1000)


  },
  // 取消订单
  qxdd(e) {
    var id = e.currentTarget.dataset.id
    wx.getStorage({
      key: 'token',
      success: function(res) {
        wx.request({
          url: app.url + '/api/order/' + id + '/cancel',
          data: '',
          header: {
            'client-token': res.data
          },
          method: 'POST',
          dataType: 'json',
          responseType: 'text',
          success: function(res) {
            console.log(res)
            if (res.data.code == 0) {
              wx.showToast({
                title: '取消成功',
                duration: 1000,
                mask: true,
                success: function(res) {},
                fail: function(res) {},
                complete: function(res) {},
              })
              wx.navigateTo({
                url: '/pages/main/orderfrom/orderfrom?id=' + navid,
                success: function(res) {},
                fail: function(res) {},
                complete: function(res) {},
              })

            }
          },
          fail: function(res) {},
          complete: function(res) {},
        })
      },
      fail: function(res) {},
      complete: function(res) {},
    })
  },
  // 申请退款
  sqtk(e) {
    var id = e.currentTarget.dataset.id
    console.log(id)
    wx.navigateTo({
      url: '/pages/main/tuikuanzhong/tuikuanzhong?id=' + id,
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    })

  },
  // 确认支付
  zfdd(e) {
    var that = this;
    var idzf = e.currentTarget.dataset.id
    console.log(idzf)
    var orders = []
    orders.push(idzf)
    console.log(orders)
    wx.getStorage({
      key: 'token',
      success: function(res) {
        wx.request({
          url: app.url + '/api/payment',
          data: {
            orders: orders,
            type: 'weixin:wxapp'
          },
          header: {
            'client-token': res.data
          },
          method: 'POST',
          dataType: 'json',
          responseType: 'text',
          success: function(res) {
            console.log(res)
            if (res.data.code == 0) {
              wx.requestPayment({
                timeStamp: res.data.data.params.timeStamp,
                nonceStr: res.data.data.params.nonceStr,
                package: res.data.data.params.package,
                signType: 'MD5',
                paySign: res.data.data.params.paySign,
                success(res) {
                  console.log(res)
                  wx.showToast({
                    title: '支付成功',
                    icon: '',
                    duration: 1000,
                    mask: true,
                    success: function(res) {
                      wx.navigateTo({
                        url: '/pages/main/orderfrom/orderfrom?id=' + navid,
                        success: function(res) {},
                        fail: function(res) {},
                        complete: function(res) {},
                      })
                    },
                    fail: function(res) {},
                    complete: function(res) {},
                  })
                  // var state;
                  // switch (that.data.navId) {
                  //   case '1':
                  //     state = 200;
                  //     break;
                  //   case '2':
                  //     state = 400;
                  //     break;
                  //   case '3':
                  //     state = 500;
                  //     break;
                  //   case '4':
                  //     state = 600;
                  //     break;
                  // }
                  // console.log(state)
                  // wx.getStorage({
                  //   key: 'token',
                  //   success: function(res) {
                  //     wx.request({
                  //       url: app.url + '/api/order/paginate',
                  //       data: {
                  //         state: state
                  //       },
                  //       header: {
                  //         'client-token': res.data
                  //       },
                  //       method: 'GET',
                  //       dataType: 'json',
                  //       responseType: 'text',
                  //       success: function(res) {
                  //         console.log(res)
                  //         if (res.data.code == 0) {
                  //           that.setData({
                  //             list: res.data.data.results
                  //           })
                  //         }
                  //       },
                  //       fail: function(res) {},
                  //       complete: function(res) {},
                  //     })
                  //   },
                  //   fail: function(res) {},
                  //   complete: function(res) {},
                  // })
                },
                fail(res) {}
              })



            }
          },
          fail: function(res) {},
          complete: function(res) {},
        })
      },
      fail: function(res) {},
      complete: function(res) {},
    })
  },
  // 确认收货
  qrsh(e) {
    var id = e.currentTarget.dataset.id
    wx.getStorage({
      key: 'token',
      success: function(res) {
        wx.request({
          url: app.url + '/api/order/' + id + '/receive',
          data: '',
          header: {
            'client-token': res.data
          },
          method: 'POST',
          dataType: 'json',
          responseType: 'text',
          success: function(res) {
            console.log(res)
            if (res.data.code == 0) {
              wx.navigateTo({
                url: '/pages/main/orderfrom/orderfrom?id=4',
                success: function(res) {},
                fail: function(res) {},
                complete: function(res) {},
              })

            }
          },
          fail: function(res) {},
          complete: function(res) {},
        })
      },
      fail: function(res) {},
      complete: function(res) {},
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function(options) {
    // if (options.name != undefined) {
    //   that.setData({
    //     xming: options.name,
    //     dianhua: options.tel,
    //     dizhi: options.dizhi
    //   })
    //   console.log(that.data.xming)
    // }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})