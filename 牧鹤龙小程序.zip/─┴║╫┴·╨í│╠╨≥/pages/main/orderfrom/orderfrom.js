// pages/main/orderfrom/orderfrom.js
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    nav: [{
        title: "待付款",
        id: 1
      },
      {
        title: "待发货",
        id: 2
      },
      {
        title: "待收货",
        id: 3
      },
      {
        title: "已完成",
        id: 4
      },
    ],
    navId: 1,
    list: [{
      dingdanhao: "454646461345674",
      zhuangtai: "已完成",
      picture: "../../image/erweima.png",
      title: '小鸡饲料喂鸡饲料玉米鸡食鱼...',
      jine: "20.00",
      shuliang: "X1",
      peisong: "快递配送  2袋",
      hbdk: "200.00",
      shifu: "200.00",
      kefu: "400-888888"
    }]
  },
  navtz(e) {
    var that = this;
    console.log(e.currentTarget.dataset.id)
    that.setData({
      navId: e.currentTarget.dataset.id
    })
    console.log(that.data.navId)
    var state;
    switch (that.data.navId) {
      case 1:
        state = 200;
        break;
      case 2:
        state = 400;
        break;
      case 3:
        state = 500;
        break;
      case 4:
        state = 600;
        break;
    }
    console.log(state)
    wx.getStorage({
      key: 'token',
      success: function(res) {
        wx.request({
          url: app.url + '/api/order/paginate',
          data: {
            state: state
          },
          header: {
            'client-token': res.data
          },
          method: 'GET',
          dataType: 'json',
          responseType: 'text',
          success: function(res) {
            console.log(res)
            if (res.data.code == 0) {
              that.setData({
                list: res.data.data.results
              })
              console.log(that.data.list)
            }
          },
          fail: function(res) {},
          complete: function(res) {},
        })
      },
      fail: function(res) {},
      complete: function(res) {},
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    wx.setNavigationBarTitle({
      title: '牧鹤在线',
    })
    var that = this;
    if (options.id) {
      that.setData({
        navId: options.id
      })
    }
    console.log(that.data.navId)
    var state;
    switch (that.data.navId.toString()) {
      case '1':
        state = 200;
        break;
      case '2':
        state = 400;
        break;
      case '3':
        state = 500;
        break;
      case '4':
        state = 600;
        break;
    }
    console.log(state)
    wx.getStorage({
      key: 'token',
      success: function(res) {
        wx.request({
          url: app.url + '/api/order/paginate',
          data: {
            state: state
          },
          header: {
            'client-token': res.data
          },
          method: 'GET',
          dataType: 'json',
          responseType: 'text',
          success: function(res) {
            console.log(res)
            if (res.data.code == 0) {
              that.setData({
                list: res.data.data.results
              })
            }
          },
          fail: function(res) {},
          complete: function(res) {},
        })
      },
      fail: function(res) {},
      complete: function(res) {},
    })

  },
  // 取消订单
  qxdd(e) {
    console.log('取消订单',e,e.currentTarget.dataset.dd.id, e.currentTarget.dataset.id)
    var id = e.currentTarget.dataset.dd.id
   var navid = e.currentTarget.dataset.id
    app.globalData.ddlb = e.currentTarget.dataset.dd
    wx.navigateTo({
      url: '/pages/main/dingdanyemiantiaozhuan/dingdanyemiantiaozhuan?id=' + navid,
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    })
  },
  // 立即评价
  ljpj(e){
    app.globalData.ddlb = e.currentTarget.dataset.dd
   wx.navigateTo({
     url: '/pages/main/evaluate/evaluate',
     success: function(res) {},
     fail: function(res) {},
     complete: function(res) {},
   })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})