// pages/main/favorable/favorable.js
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    list:[
      {title:"购买商品",place:"-￥10",zhuangtai:"已支付",time:"09-11 11:33"},
      {title:"购买商品",place:"-￥10",zhuangtai:"已支付",time:"09-11 11:33"},
      {title:"购买商品",place:"-￥10",zhuangtai:"已支付",time:"09-11 11:33"}
    ],
    data:"",
    balance:"0"
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // var jlj = options.jlj
    wx.setNavigationBarTitle({
      title: '牧鹤在线',
    })

    var that = this;
    wx.getStorage({
      key: 'token',
      success: function (res) {
        wx.request({
          url: app.url + '/api/user/info',
          data: '',
          header: {
            'client-token': res.data
          },
          method: 'GET',
          dataType: 'json',
          responseType: 'text',
          success: function (res) {
            console.log(res)
            console.log(res.data.data.codeUrl)
            console.log(res.data.data.isAgency)
            if (res.data.code == 0) {
              balance = res.data.data.balance
              app.globalData.balance = res.data.data.balance
              that.setData({
                balance: app.globalData.balance
              })
            }
          },
          fail: function (res) { },
          complete: function (res) { },
        })
      },
      fail: function (res) { },
      complete: function (res) { },
    })
    
    wx.getStorage({
      key: 'token',
      success: function(res) {
        wx.request({
          url: app.url + '/api/income/paginate',
          data: '',
          header: { 'client-token': res.data},
          method: 'GET',
          dataType: 'json',
          responseType: 'text',
          success: function (res) { 
            console.log(res)
            if(res.data.code==0){
              that.setData({
                data:res.data.data
              })
              
            }
          },
          fail: function (res) { },
          complete: function (res) { },
        })
      },
      fail: function(res) {},
      complete: function(res) {},
    })
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})