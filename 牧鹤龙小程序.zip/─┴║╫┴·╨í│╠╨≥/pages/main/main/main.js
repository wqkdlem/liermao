// pages/main/main/main.js
var app = getApp()
var isAgency;
var balance;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    list: [{
        img: "../../image/dfk.png",
        title: "待付款",
        id: 1,
        shuliang: "",
        state: 200
      },
      {
        img: "../../image/dfh.png",
        title: "待发货",
        id: 2,
        shuliang: "",
        state: 400
      },
      {
        img: "../../image/dsh.png",
        title: "待收货",
        id: 3,
        shuliang: "",
        state: 500
      },
      {
        img: "../../image/ywc.png",
        title: "已完成",
        id: 4,
        shuliang: "",
        state: 600
      },
    ],
    listtz: [{
        img: "../../image/wofuwu.png",
        title: '我服务的养殖户',
        id: 0
      },
      {
        img: "../../image/shouhuo.png",
        title: '收货地址',
        id: 2
      },
      {
        img: "../../image/yijian.png",
        title: '意见反馈',
        id: 3
      },
      {
        img: "../../image/kefuzx.png",
        title: '客服中心',
        id: 4
      },
      {
        img: "../../image/gywm.png",
        title: '关于我们',
        id: 5
      }
    ],
    listtz1: [{
        img: "../../image/shenqing.png",
        title: '申请为平台服务经理',
        id: 1
      },
      {
        img: "../../image/shouhuo.png",
        title: '收货地址',
        id: 2
      },
      {
        img: "../../image/yijian.png",
        title: '意见反馈',
        id: 3
      },
      {
        img: "../../image/kefuzx.png",
        title: '客服中心',
        id: 4
      },
      {
        img: "../../image/gywm.png",
        title: '关于我们',
        id: 5
      }
    ],
    data: "",
    ermdz: "",
    avatarUrl: "",
    nickName: "",
    isAgency: ""
  },
  tzddxq(e) {
    wx.navigateTo({
      url: '/pages/main/orderfrom/orderfrom?id=' + e.currentTarget.dataset.id,
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    wx.setNavigationBarTitle({
      title: '我的',
    })
    var that = this;
   
    var list = that.data.list;
    console.log(that.data.list[0].state)
    for (let e = 0; e < that.data.list.length; e++) {
      console.log(e)
      let state = that.data.list[e].state
      console.log(state)
      wx.getStorage({
        key: 'token',
        success: function(res) {
          wx.request({
            url: app.url + '/api/order/paginate',
            data: {
              state: state
            },
            header: {
              'client-token': res.data
            },
            method: 'GET',
            dataType: 'json',
            responseType: 'text',
            success: function(res) {
              console.log('页面',res)
              if (res.data.code == 0) {
                list[e].shuliang = res.data.data.total
                console.log('页面',res.data.data.total)
                that.setData({
                  list: list
                })
              }
            },
            fail: function(res) {},
            complete: function(res) {},
          })
        },
        fail: function(res) {},
        complete: function(res) {},
      })
    }

    wx.getStorage({
      key: 'avatarUrl',
      success: function(res) {
        console.log(res.data, "头像地址")
        that.setData({
          avatarUrl: res.data,
        })
      },
      fail: function(res) {},
      complete: function(res) {},
    })
    wx.getStorage({
      key: 'nickName',
      success: function(res) {
        console.log(res.data, "昵称")
        that.setData({
          nickName: res.data,
        })
      },
      fail: function(res) {},
      complete: function(res) {},
    })
    wx.getStorage({
      key: 'token',
      success: function(res) {
        wx.request({
          url: app.url + '/api/user/info',
          data: '',
          header: {
            'client-token': res.data
          },
          method: 'GET',
          dataType: 'json',
          responseType: 'text',
          success: function(res) {
            console.log(res)
            console.log(res.data.data.codeUrl)
            console.log(res.data.data.isAgency)
            if (res.data.code == 0) {
              balance = res.data.data.balance
              app.globalData.balance = res.data.data.balance
              isAgency = res.data.data.isAgency
              that.setData({
                data: res.data.data,
                ermdz: res.data.data.codeUrl,
                isAgency: res.data.data.isAgency
              })
              if (isAgency) {
                that.setData({
                  ermdz: res.data.data.agencyCodeUrl
                })
              } else {
                that.setData({
                  ermdz: res.data.data.codeUrl
                })
              }

            }
          },
          fail: function(res) {},
          complete: function(res) {},
        })
      },
      fail: function(res) {},
      complete: function(res) {},
    })

  },
  // 跳转到优惠红包列表
  yhhb() {
    wx.navigateTo({
      url: '/pages/main/favorable/favorable?balance=' + balance,
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    })
  },
  // 跳转详情
  tzxq(e) {
    console.log(e.currentTarget.dataset.id)
    var id = e.currentTarget.dataset.id;
    // 收货地址
    if (id == 2) {
      wx.navigateTo({
        url: '/pages/main/shippingAddress/shippingAddress',
        success: function(res) {},
        fail: function(res) {},
        complete: function(res) {},
      })
    } else if (id == 1) {
      wx.getStorage({
        key: 'sql',
        success: function(res) {
          console.log(res.data)
          wx.showToast({
            title: '申请中,请等待',
            icon: '',
            image: '',
            duration: 1000,
            mask: true,
            success: function(res) {},
            fail: function(res) {},
            complete: function(res) {},
          })
        },
        fail: function(res) {
          wx.navigateTo({
            url: '/pages/main/appleyFor/appleyFor',
            success: function(res) {},
            fail: function(res) {},
            complete: function(res) {},
          })
        },
        complete: function(res) {},
      })

    } else if (id == 3) {
      wx.navigateTo({
        url: '/pages/main/feedback/feedback',
        success: function(res) {},
        fail: function(res) {},
        complete: function(res) {},
      })
    } else if (id == 4) {
      wx.navigateTo({
        url: '/pages/main/callCenter/callCenter',
        success: function(res) {},
        fail: function(res) {},
        complete: function(res) {},
      })
    } else if (id == 5) {
      wx.navigateTo({
        url: '/pages/main/aboutUs/aboutUs',
        success: function(res) {},
        fail: function(res) {},
        complete: function(res) {},
      })
    } else if (id == 0) {
      wx.navigateTo({
        url: '/pages/main/theFarmersIServe/theFarmersIServe',
        success: function(res) {},
        fail: function(res) {},
        complete: function(res) {},
      })
    }
  },
  //推广列表
  tglb() {
    wx.navigateTo({
      url: '/pages/main/theFarmersIServe/theFarmersIServe',
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    })
  },
  // 查看全部的订单
  qbdd() {
    wx.navigateTo({
      url: '/pages/main/orderfrom/orderfrom',
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    })
  },
  tgewm() {

    var that = this;
    console.log(that.data.ermdz)
    wx.navigateTo({
      url: '/pages/main/generalize/generalize?ewm=' + that.data.ermdz,
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    })
  },
  tglb2(){
    wx.navigateTo({
      url: '/pages/main/myPromotion/myPromotion',
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    var that = this;
    wx.getStorage({
      key: 'token',
      success: function(res) {
        wx.request({
          url: app.url + '/api/user/info',
          data: '',
          header: {
            'client-token': res.data
          },
          method: 'GET',
          dataType: 'json',
          responseType: 'text',
          success: function(res) {
            console.log(res)
            console.log(res.data.data.codeUrl)
            console.log(res.data.data.isAgency)
            if (res.data.code == 0) {
              balance = res.data.data.balance
              isAgency = res.data.data.isAgency
              that.setData({
                data: res.data.data,
                ermdz: res.data.data.codeUrl,
                isAgency: res.data.data.isAgency
              })
              if (isAgency) {
                that.setData({
                  ermdz: res.data.data.agencyCodeUrl
                })
              } else {
                that.setData({
                  ermdz: res.data.data.codeUrl
                })
              }

            }
          },
          fail: function(res) {},
          complete: function(res) {},
        })
      },
      fail: function(res) {},
      complete: function(res) {},
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})