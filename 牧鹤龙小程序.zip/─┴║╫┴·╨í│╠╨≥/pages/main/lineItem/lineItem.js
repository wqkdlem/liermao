// pages/main/lineItem/lineItem.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    list:{
      "id": 
      "5c6a36421bab2200064018d8" ,
      "title": 
      "Title" ,
      "pic": 
      "http://img.maichong.it/logo/a1.png" ,
      "address": 
      {
      "id": 
      "5c10ce8ae287fd000656a3f2" ,
      "tel": 
      "18000000000" ,
      "name": 
      "王先生" ,
      "country": 
      "中国" ,
      "province": 
      "河南省" ,
      "city": 
      "郑州市" ,
      "district": 
      "金水区" ,
      "detail": 
      "经三路鑫苑金融广场" ,
      "createdAt": 
      "2018-12-12T09:14:48.668Z" ,
      "isDefault": 
      true
      } ,
      "shipping": 
      "20" ,
      "total": 
      100 ,
      "pay": 
      120 ,
      "payed": 
      0 ,
      "state": 
      200 ,
      "createdAt": 
      "2018-12-12T09:14:48.668Z" ,
      "goods": 
      [
      {
      "id": 
      "5c10ce8ae287fd000656a3f2" ,
      "pic": 
      "http://img.maichong.it/logo/a1.png" ,
      "title": 
      "Title" ,
      "order": 
      "5c10cecae287fd000656a3f4" ,
      "goods": 
      "5c10cecae287fd000656a3f4" ,
      "skuDesc": 
      "规格:10KG;" ,
      "price": 
      100 ,
      "discount": 
      88.8 ,
      "quantity": 
      1 ,
      "shipping": 
      0 ,
      "total": 
      100 ,
      "refundedAmount": 
      0 ,
      "refundedQuantity": 
      0 ,
      "refundReason": 
      "%h51hE" ,
      "refundAmount": 
      0 ,
      "refundQuantity": 
      0 
      } 
      ] ,
      "shipped": 
      true,
      "closed": 
      true,
      "failure": 
      "支付超时" ,
      "paymentTimeout": 
      "2018-12-12T09:14:48.668Z" ,
      "receiveTimeout": 
      "2018-12-12T09:14:48.668Z" ,
      "refundTimeout": 
      "2018-12-12T09:14:48.668Z" ,
      "refundedAmount": 
      0 ,
      "refundedQuantity": 
      0 ,
      "refundReason": 
      "@mqU*" ,
      "refundAmount": 
      0 ,
      "refundQuantity": 
      0 ,
      "agency": 
      "5c6ba5c81bab220006401b02" ,
      "promoter": 
      "5c6ba5c81bab220006401b02" 
      }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.setNavigationBarTitle({
      title: '牧鹤在线',
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})