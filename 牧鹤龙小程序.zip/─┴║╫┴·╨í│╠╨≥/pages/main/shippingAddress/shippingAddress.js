// pages/main/shippingAddress/shippingAddress.js
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    list: [],
    zhanshi: false,
    dzid: 0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    wx.setNavigationBarTitle({
      title: '牧鹤在线',
    })
    var that = this;
    console.log(123)
   
    wx.getStorage({
      key: 'token',
      success: function(res) {
        wx.request({
          url: app.url + '/api/address',
          data: '',
          header: {
            'client-token': res.data
          },
          method: 'GET',
          dataType: 'json',
          responseType: 'text',
          success: function(res) {
            console.log(res)
            if (res.data.code == 0) {
              that.setData({
                list: res.data.data
              })
            }

          },
          fail: function(res) {},
          complete: function(res) {},
        })
      },
      fail: function(res) {},
      complete: function(res) {},
    })

  },
  // 设为默认事件
  swmr(e) {
    var that = this;
    that.setData({
      dzid: e.currentTarget.dataset.index
    })
    wx.getStorage({
      key: 'token',
      success: function (res) {
        wx.request({
          url: app.url + '/api/address/' + that.data.dzid,
          data: {
            id: that.data.dzid,
            isDefault:true
          },
          header: {
            'client-token': res.data
          },
          method: 'PUT',
          dataType: 'json',
          responseType: 'text',
          success: function (res) {
            console.log(res)
            if (res.data.code == 0) {
              wx.getStorage({
                key: 'token',
                success: function (res) {
                  wx.request({
                    url: app.url + '/api/address',
                    data: '',
                    header: {
                      'client-token': res.data
                    },
                    method: 'GET',
                    dataType: 'json',
                    responseType: 'text',
                    success: function (res) {
                      console.log(res)
                      if (res.data.code == 0) {
                        that.setData({
                          list: res.data.data
                        })
                      }

                    },
                    fail: function (res) { },
                    complete: function (res) { },
                  })
                },
                fail: function (res) { },
                complete: function (res) { },
              })
            }
          },
          fail: function (res) { },
          complete: function (res) { },
        })
      },
      fail: function (res) { },
      complete: function (res) { },
    })
  },
  // 修改地址事件
  xgdz() {
    wx.navigateTo({
      url: '/pages/main/newAddress/newAddress',
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    })
  },
  //新增地址事件
  xzdz() {
    wx.navigateTo({
      url: '/pages/main/newAddress/newAddress',
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    })
  },
  scdz(e) {
    var that = this;
    var id;
    console.log(e.currentTarget.dataset.id)
    id = e.currentTarget.dataset.id
    wx.getStorage({
      key: 'token',
      success: function(res) {
        wx.request({
          url: app.url + '/api/address/' + id,
          data: {
            id: id
          },
          header: {
            'client-token': res.data
          },
          method: 'DELETE',
          dataType: 'json',
          responseType: 'text',
          success: function(res) {
            console.log(res)
            if (res.data.code == 0) {
              wx.getStorage({
                key: 'token',
                success: function(res) {
                  wx.request({
                    url: app.url + '/api/address',
                    data: '',
                    header: {
                      'client-token': res.data
                    },
                    method: 'GET',
                    dataType: 'json',
                    responseType: 'text',
                    success: function(res) {
                      console.log(res)
                      if (res.data.code == 0) {
                        that.setData({
                          list: res.data.data
                        })
                      }

                    },
                    fail: function(res) {},
                    complete: function(res) {},
                  })
                },
                fail: function(res) {},
                complete: function(res) {},
              })
            }
          },
          fail: function(res) {},
          complete: function(res) {},
        })
      },
      fail: function(res) {},
      complete: function(res) {},
    })

  },
  // 修改地址
  bjdz(e) {
    var id;
    console.log(e.currentTarget.dataset.id)
    id = e.currentTarget.dataset.id
    wx.navigateTo({
      url: '/pages/main/newAddress/newAddress?id=' + id,
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {
    wx.reLaunch({
      url: '/pages/main/main/main'
    })
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})