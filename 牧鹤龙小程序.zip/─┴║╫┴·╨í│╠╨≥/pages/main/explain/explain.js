// pages/main/explain/explain.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
list:[
  '1. 系统每天赠送一次抽奖机会；','2.点击下方分享好友或者朋友圈可再获得一次抽奖机会；','3.若您邀请的朋友通过积分兑换了补贴凭证，那么您也将获得他领到补贴数额的5%的奖励'
]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.setNavigationBarTitle({
      title: '牧鹤在线',
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})