// pages/main/evaluate/evaluate.js
var app = getApp()
var tempFilePaths;
let pjid;
let tpid;
let goods=[];
let arr = { content: "", pics: "", orderGoods: "" };
  let imgstr=[];
Page({

  /**
   * 页面的初始数据
   */
  data: {
  data:"",
  imgstr:[],
    infos:[],
    value:""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.setNavigationBarTitle({
      title: '评价',
    })
    var that = this;
console.log(app.url)
    app.globalData.ddlb
    that.setData({
      data: app.globalData.ddlb
    })
    console.log(that.data.data)
    for (let q = 0; q < that.data.data.goods.length; q++) {
      // console.log("测试获取商品id", 1)
      arr.orderGoods = that.data.data.goods[q].id
      // console.log("商品id", arr.orderGoods)
      // console.log("当前商品id", pjid)
      // if (arr.orderGoods = pjid) {
      //   arr.content = e.detail.value
      // }
      console.log(arr.content)
      console.log(arr.orderGoods)
      goods.push(arr)
    }
  },
  // 上传图片
  sctp(e){
    console.log(e.currentTarget.dataset.id)
    tpid = e.currentTarget.dataset.id;
    var that = this;
    // 上传图片事件
    wx.chooseImage({
      success: function (res) {
        
        let infos =[]
        console.log('rest',res.tempFilePaths)
        for (let i = 0; i < res.tempFilePaths.length; i++) {
          let aaa
          if (res.tempFilePaths.length && res.tempFilePaths[i]){
          console.log('restpath', JSON.stringify(res.tempFilePaths[i]))
          }
          aaa =res.tempFilePaths[i]
          console.log('respath0',aaa)
          wx.getStorage({
            key: 'token',
            success: function(res) {
              wx.uploadFile({
                url: app.url + '/api/image',
                filePath: aaa,
                name: 'file',
                method: 'POST',
                header: { 'client-token': res.data},
                formData: {},
                success: function(res) {
                  console.log('数据',res)
                 let data = res.data
                  
                  console.log(data)
                  var data2 = JSON.parse(data)
                  infos.push(data2.data.url)
                  console.log(data2)
                  if (data2.code == 0) {
                    imgstr.push(data2.data[0])
                    console.log(data2.data[0])
                    console.log(imgstr)
                    that.setData({
                      imgstr: imgstr
                    })
                    console.log(imgstr)
                    console.log(that.data.imgstr)
                    console.log(goods.length)
                    for (let p = 0; p < goods.length; p++) {
                      console.log("测试获取商品id", 1)
                      // arr.orderGoods = that.data.data.goods[f].id
                      console.log("商品id", goods[p].orderGoods)
                      console.log("当前商品id", pjid)
                      if (goods[p].orderGoods == pjid) {
                        console.log("2")
                        goods[p].pics = infos
                      }
                      console.log(goods)
                    }
                  }
                  console.log('接口', infos)
                  setTimeout(()=>{
                    that.setData({
                      infos: infos
                    })
                  },100)
                  
                },
                fail: function(res) {},
                complete: function(res) {},
              })
            },
            fail: function(res) {},
            complete: function(res) {},
          })
        }
        

      }
    })

  },
  // 发布评价
  fb(){
    var that = this;
    // var goods=[]
    // arr.content = that.data.value,
    //   arr.pics = that.data.infos,
    //   arr.orderGoods = that.data.data.id
    // goods.push(JSON.stringify(arr))
    // console.log('评价列表', arr)
    console.log(goods)
     wx.getStorage({
       key: 'token',
       success: function(res) {
         wx.request({
           url: app.url +'/api/order/'+that.data.data.id+'/comment',
           data:{
             goods: goods
           },
           header: { 'client-token': res.data},
           method: 'POST',
           dataType: 'json',
           responseType: 'text',
           success: function(res) {
             console.log(res)
             if(res.data.code==0){
               wx.showToast({
                 title: '评价成功',
                 icon: '',
                 image: '',
                 duration: 0,
                 mask: true,
                 success: function(res) {},
                 fail: function(res) {},
                 complete: function(res) {},
               })
               wx.switchTab({
                 url: '/pages/main/main/main',
                 success: function(res) {},
                 fail: function(res) {},
                 complete: function(res) {},
               })
             }
           },
           fail: function(res) {},
           complete: function(res) {},
         })
       },
       fail: function(res) {},
       complete: function(res) {},
     })
  },
  hqpjnr(e){
    var that = this;
    pjid = e.currentTarget.dataset.id
    console.log(e.currentTarget.dataset.id)
    console.log(e.detail.value)
    // that.setData({
    //   value: e.detail.value
    // })
    console.log(that.data.data.goods.length)
    for (let s = 0; s < goods.length; s++){
      console.log("测试获取商品id",1)
      // arr.orderGoods = that.data.data.goods[f].id
      console.log("商品id",arr.orderGoods)
      console.log("当前商品id", pjid)
      if (goods[s].orderGoods == pjid){
        console.log("1")
        console.log(goods)
        console.log(goods[s].arr)
        goods[s].content = e.detail.value
      }
      console.log(goods)
    }
    
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})