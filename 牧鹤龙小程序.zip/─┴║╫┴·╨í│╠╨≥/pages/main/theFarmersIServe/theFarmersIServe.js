// pages/main/theFarmersIServe/theFarmersIServe.js
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
      list:{
        xdzje:"150",
        flyjs:"150",
        flwjs:"150"
      },
      yzh:[]
      
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.setNavigationBarTitle({
      title: '牧鹤在线',
    })
    var that = this;
    wx.getStorage({
      key: 'token',
      success: function (res) {
        wx.request({
          url: app.url + '/api/agency-order/count',
          data: '',
          header: { 'client-token': res.data },
          method: 'GET',
          dataType: 'json',
          responseType: 'text',
          success: function (res) {
            console.log(res)
            if (res.data.code == 0) {
              that.setData({
                list: res.data.data,
                // yzh: res.data.data.results
              })
            }
          },
          fail: function (res) { },
          complete: function (res) { },
        })
        wx.request({
          url: app.url + '/api/agency/paginate',
          data: '',
          header: { 'client-token': res.data },
          method: 'GET',
          dataType: 'json',
          responseType: 'text',
          success: function(res) {
            console.log(res)
            if(res.data.code==0){
              that.setData({
                // list: res.data.data,
                yzh: res.data.data.results
              })
            }
          },
          fail: function(res) {},
          complete: function(res) {},
        })
      },
      fail: function (res) { },
      complete: function (res) { },
    })
  },
  cksyxxlb(){
 wx.navigateTo({
   url: '/pages/main/detailsOfFarmers/detailsOfFarmers',
   success: function(res) {},
   fail: function(res) {},
   complete: function(res) {},
 })
  },
  yzhddxq(e){
    var id = e.currentTarget.dataset.id
    wx.navigateTo({
      url: '/pages/main/detailsOfFarmers/detailsOfFarmers?id='+id,
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) { },
    })
  },
  sqjs(){
    wx.getStorage({
      key: 'token',
      success: function(res) {
        var token = res.data;
        wx.request({
          url: app.url +'/api/agency-withdraw',
          data: '',
          header: { 'client-token': token},
          method: 'POST',
          dataType: 'json',
          responseType: 'text',
          success: function(res) {
            console.log(res)
            if(res.data.code==0){
              wx.request({
                url: app.url + '/api/agency-order/count',
                data: '',
                header: { 'client-token': token},
                method: 'GET',
                dataType: 'json',
                responseType: 'text',
                success: function (res) {
                  console.log(res)
                  if (res.data.code == 0) {
                    wx.showToast({
                      title: '开始结算请等待',
                      icon: '',
                      image: '',
                      duration: 1000,
                      mask: true,
                      success: function(res) {},
                      fail: function(res) {},
                      complete: function(res) {},
                    })
                    that.setData({
                      list: res.data.data,
                      // yzh: res.data.data.results
                    })
                  }
                },
                fail: function (res) { },
                complete: function (res) { },
              })
            }
          },
          fail: function(res) {},
          complete: function(res) {},
        })
      },
      fail: function(res) {},
      complete: function(res) {},
    })
  },
  // 推广奖励说明
  tgjlsm(){
    wx.navigateTo({
      url: '/pages/main/bonus/bonus',
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})