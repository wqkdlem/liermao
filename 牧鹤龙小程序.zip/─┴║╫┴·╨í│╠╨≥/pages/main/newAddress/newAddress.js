// pages/main/newAddress/newAddress.js
var app = getApp();
var id;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    array: ['美国', '中国', '巴西', '日本'],
    objectArray: [{
        id: 0,
        name: '美国'
      },
      {
        id: 1,
        name: '中国'
      },
      {
        id: 2,
        name: '巴西'
      },
      {
        id: 3,
        name: '日本'
      }
    ],
    index: 0,
    region: ['河南省', '郑州市', '金水区'],
    xm: "",
    sjh: "",
    xxdz: ""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.setNavigationBarTitle({
      title: '添加地址',
    })
    console.log(options.id)
    id = options.id;
  },
  bindRegionChange(e) {
    var that = this;
    console.log(123)
    console.log(e)
    that.setData({
      region: e.detail.value
    })
  },
  hqxm(e) {
    console.log(e.detail.value)
    var that = this;
    that.setData({
      xm: e.detail.value
    })
  },
  hqsjh(e) {
    console.log(e.detail.value)
    var that = this;
    that.setData({
      sjh: e.detail.value
    })
  },
  hqxxdz(e) {
    console.log(e.detail.value)
    var that = this;
    that.setData({
      xxdz: e.detail.value
    })
  },
  // 保存新增地址事件
  bc() {
    var that = this;
    if (that.data.xm.length == 0) {
      wx.showToast({
        title: '请输入姓名',
        image: '../../image/cuohao.png',
        duration: 1000,
      })
    } else if (that.data.sjh.length == 0) {
      wx.showToast({
        title: '请输入手机号',
        image: '../../image/cuohao.png',
        duration: 1000,
      })
    }
    //  else if (that.data.sjh.length >= 0) {
    //   var that = this;
    //   var myreg = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1})|(17[0-9]{1}))+\d{8})$/;
    //   if (that.data.sjh.length != 11) {
    //     wx.showToast({
    //       title: '手机号长度有误！',
    //       image: '../../image/cuohao.png',
    //       duration: 1500
    //     })
    //     return false;
    //   } else if (!myreg.test(that.data.sjh)) {
    //     wx.showToast({
    //       title: '手机号有误！',
    //       image: '../../image/cuohao.png',
    //     })
    //     return false;
    //   }
    // }
    else if(that.data.region.length==0){
      wx.showToast({
        title: '请输入收货地址',
        image: '../../image/cuohao.png',
        duration: 1000,
      })
    }else if(that.data.xxdz.length==0){
      wx.showToast({
        title: '请输入详细地址',
        image: '../../image/cuohao.png',
        duration: 1000,
      })
    }else{
      wx.getStorage({
        key: 'token',
        success: function(res) {
          if(id!=undefined){
            wx.request({
              url: app.url +'/api/address/'+id,
              data: {
                id:id,
                tel: that.data.sjh,
                name: that.data.xm,
                province: that.data.region[0],
                city: that.data.region[1],
                district: that.data.region[2],
                detail: that.data.xxdz
              },
              header: { 'client-token': res.data},
              method: 'PUT',
              dataType: 'json',
              responseType: 'text',
              success: function(res) {
                console.log(res)
                if(res.data.code==0){
                  wx.showToast({
                    title: '修改成功',
                    duration:1000
                  })
                  wx.navigateBack()
                }
              },
              fail: function(res) {},
              complete: function(res) {},
            })
          }else{
            wx.request({
              url: app.url + '/api/address' ,
              data: {
                tel: that.data.sjh,
                name: that.data.xm,
                province: that.data.region[0],
                city: that.data.region[1],
                district: that.data.region[2],
                detail: that.data.xxdz
              },
              header: { 'client-token': res.data },
              method: 'POST',
              dataType: 'json',
              responseType: 'text',
              success: function (res) {
                console.log(res)
                if (res.data.code == 0) {
                  wx.showToast({
                    title: '添加成功',
                    duration: 1000
                  })
                  wx.navigateBack()
                }
               },
              fail: function (res) { },
              complete: function (res) { },
            })
          }
        },
        fail: function(res) {},
        complete: function(res) {},
      })
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})