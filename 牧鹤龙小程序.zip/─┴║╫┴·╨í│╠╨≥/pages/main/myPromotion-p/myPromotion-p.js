// pages/main/myPromotion-p/myPromotion-p.js
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    list:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // console.log(options.isAgency)
    wx.setNavigationBarTitle({
      title: '牧鹤在线',
    })
    var that = this;
    if (options.isAgency){
      wx.getStorage({
      key: 'token',
      success: function(res) {
        wx.request({
          url: app.url +'/api/promoter-order/paginate',
          data: '',
          header: {
            'client-token': res.data
          },
          method: 'GET',
          dataType: 'json',
          responseType: 'text',
          success: function (res) {
             console.log(res)
             if(res.data.code==0){
               that.setData({
                 list: res.data.data.results
               })
             }
           },
          fail: function (res) { },
          complete: function (res) { },
        })
      },
      fail: function(res) {},
      complete: function(res) {},
    })
    }else{
      wx.getStorage({
        key: 'token',
        success: function (res) {
          wx.request({
            url: app.url + '/api/promoter-order/paginate',
            data: '',
            header: {
              'client-token': res.data
            },
            method: 'GET',
            dataType: 'json',
            responseType: 'text',
            success: function (res) {
              console.log(res)
              if (res.data.code == 0) {
                that.setData({
                  list: res.data.data.results
                })
              }
            },
            fail: function (res) { },
            complete: function (res) { },
          })
        },
        fail: function (res) { },
        complete: function (res) { },
      })
    }
    
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})