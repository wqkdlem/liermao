// pages/main/detailsOfFarmers/detailsOfFarmers.js
var app = getApp()
var id;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    list:[
      {title:"已结算",id:"1"},{title:"未结算",id:"2"}
    ],
    navId:1,
    count:[
      {title:"小鸡饲料 颗粒雏鸡饲料喂鸡饲料玉米鸡食鱼",yhxd:"128.00",yhyl:"10袋/400kg",zje:"1280.00",nhjg:"128.00",nhsl:"10袋/400kg",nhzje:"128.00",ptyflje:"18.00",dz:"金水区花园路农科路",gmsj:"2018-12-09  7:26"}
    ],
    state:"",
    data:"",
    years:2019,
    months:3
  },
  btaNav(e){
    var that = this;
    console.log(e.currentTarget.dataset.id)
    that.setData({
      navId: e.currentTarget.dataset.id
    })
    if (that.data.navId == 1) {
      that.setData({
        state: 'balanced'
      })
    } else if (that.data.navId == 2) {
      that.setData({
        state: 'pending'
      })
    }
    
    if (id) {
      wx.getStorage({
        key: 'token',
        success: function (res) {
          wx.request({
            url: app.url + '/api/agency-order/paginate',
            data: {
              state: that.data.state,
              user: id,
              // month: that.data.months
            },
            header: { 'client-token': res.data },
            method: 'GET',
            dataType: 'json',
            responseType: 'text',
            success: function (res) {
              console.log(res)
              if (res.data.code == 0) {
                for (var i in res.data.data.results) {
                  console.log(res.data.data.results[i].createdAt)
                  console.log(res.data.data.results[i].createdAt.split('T')[0])
                  console.log(res.data.data.results[i].createdAt.split('T')[1].split(':')[0])
                  console.log(res.data.data.results[i].createdAt.split(':')[1])
                  res.data.data.results[i].createdAt = res.data.data.results[i].createdAt.split('T')[0] + '  ' + res.data.data.results[i].createdAt.split('T')[1].split(':')[0] + ':' + res.data.data.results[i].createdAt.split(':')[1]
                  console.log(res.data.data.results[i].createdAt)
                }
                setTimeout(()=>{
                  that.setData({
                    data: res.data.data
                  })
                },100)
                
              }
            },
            fail: function (res) { },
            complete: function (res) { },
          })
        },
        fail: function (res) { },
        complete: function (res) { },
      })
    } else {
      wx.getStorage({
        key: 'token',
        success: function (res) {
          wx.request({
            url: app.url + '/api/agency-order/paginate',
            data: {
              state: that.data.state
            },
            header: { 'client-token': res.data },
            method: 'GET',
            dataType: 'json',
            responseType: 'text',
            success: function (res) {
              console.log(res)
              if (res.data.code == 0) {
                that.setData({
                  data: res.data.data
                })
              }
            },
            fail: function (res) { },
            complete: function (res) { },
          })
        },
        fail: function (res) { },
        complete: function (res) { },
      })
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.setNavigationBarTitle({
      title: '确认订单',
    })
    id = options.id
    var that = this;
    if (that.data.navId == 1) {
      that.setData({
        state: 'balanced'
      })
    } else if (that.data.navId == 2) {
      that.setData({
        state: 'pending'
      })
    }

    if (id) {
      wx.getStorage({
        key: 'token',
        success: function (res) {
          wx.request({
            url: app.url + '/api/agency-order/paginate',
            data: {
              state: that.data.state,
              user: id
            },
            header: { 'client-token': res.data },
            method: 'GET',
            dataType: 'json',
            responseType: 'text',
            success: function (res) {
              console.log(res)
              if (res.data.code == 0) {
                that.setData({
                  data: res.data.data
                })
              }
            },
            fail: function (res) { },
            complete: function (res) { },
          })
        },
        fail: function (res) { },
        complete: function (res) { },
      })
    } else {
      wx.getStorage({
        key: 'token',
        success: function (res) {
          wx.request({
            url: app.url + '/api/agency-order/paginate',
            data: {
              state: that.data.state
            },
            header: { 'client-token': res.data },
            method: 'GET',
            dataType: 'json',
            responseType: 'text',
            success: function (res) {
              console.log(res)
              if (res.data.code == 0) {
                that.setData({
                  data: res.data.data
                })
              }
            },
            fail: function (res) { },
            complete: function (res) { },
          })
        },
        fail: function (res) { },
        complete: function (res) { },
      })
    }
  },
  getDateTime(e){
    console.log(e)
    console.log(e.detail.value)
    console.log(e.detail.value.split('-')[0])
    console.log(e.detail.value.split('-')[1])
    var that = this;
    that.setData({
      years: e.detail.value.split('-')[0],
      months: e.detail.value.split('-')[1]
    })
    wx.request({
      url: app.url + '/api/agency-order/paginate',
      data: {
        state: that.data.state,
        user: id,
        month: that.data.months
      },
      header: { 'client-token': res.data },
      method: 'GET',
      dataType: 'json',
      responseType: 'text',
      success: function (res) {
        console.log(res)
        if (res.data.code == 0) {
          that.setData({
            data: res.data.data
          })
        }
      },
      fail: function (res) { },
      complete: function (res) { },
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})