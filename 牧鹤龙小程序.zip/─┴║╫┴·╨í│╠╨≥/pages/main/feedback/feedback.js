// pages/main/feedback/feedback.js
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
   fknr:"",
   zishu:0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.setNavigationBarTitle({
      title: '牧鹤在线',
    })
  },
  hqyjnr(e){
    var that = this;
    console.log(e.detail.value)
    that.setData({
      fknr: e.detail.value,
      zishu: e.detail.cursor
    })
  },
  fbfk(){
    var that = this;
wx.getStorage({
  key: 'token',
  success: function(res) {
    wx.request({
      url: app.url+'/api/feedback',
      data: {
        content: that.data.fknr
      },
      header: { 'client-token': res.data},
      method: 'POST',
      dataType: 'json',
      responseType: 'text',
      success: function(res) {
        console.log(res)
        if(res.data.code==0){
          wx.showToast({
            title: '发布成功',
            icon: '',
            image: '',
            duration: 1000,
            mask: true,
            success: function(res) {},
            fail: function(res) {},
            complete: function(res) {},
          })
        }
      },
      fail: function(res) {},
      complete: function(res) {},
    })
  },
  fail: function(res) {},
  complete: function(res) {},
})
  },
  fkls(){
    wx.navigateTo({
      url: '/pages/main/fbHistory/fbHistory',
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})