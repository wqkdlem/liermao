// pages/main/confirmAnOrder/confirmAnOrder.js
var app = getApp()
var morendizhi;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    list: [{
      title: "快递配送",
      id: "1"
    }, {
      title: "上门自提",
      id: "2"
    }],
    navId: 1,
    data: "",
    address: {},
    sjxx: "",
    mjly: "",
    xxzshdz: "",
    dingdanjy: true
  },
  btaNav(e) {
    var that = this;
    console.log(e.currentTarget.dataset.id)
    that.setData({
      navId: e.currentTarget.dataset.id
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    // console.log(options)
    console.log("111111")
    app.globalData.options = options
    wx.setNavigationBarTitle({
      title: '确认订单',
    })
    var that = this;
    console.log('地址查询', app.globalData, app.globalData.address)

    console.log('global', app.globalData);
    this.setData({
      sjxx: app.globalData.config
    });

    wx.request({
      url: app.url + '/api/address',
      data: '',
      header: {
        'client-token': app.globalData.token
      },
      method: 'GET',
      dataType: 'json',
      responseType: 'text',
      success: function(res) {
        console.log(res)
        if (res.data.code == 0) {
          //  that.setData({
          //    dzlist:res.data.data
          //  })
          var defaultAddress = null;
          for (var a = 0; a < res.data.data.length; a++) {
            if (!defaultAddress) defaultAddress = res.data.data[a];
            if (res.data.data[a].isDefault) {
              defaultAddress = res.data.data[a];
              break;
            }
          }
          if (defaultAddress) {
            that.setData({
              address: defaultAddress
            });
            morendizhi = defaultAddress;
          }
          console.log(res.data.data)
          console.log(res.data.data.length)
          if (res.data.data.length > 0) {
            that.setData({
              xxzshdz: false
            })
          } else {
            that.setData({
              xxzshdz: true
            })
          }
        }
      },
      fail: function(res) {},
      complete: function(res) {},
    })


    wx.getStorage({
      key: 'orders',
      success: function(res) {
        // console.log(res.data)
        console.log(res.data, "进入页面的新订单")
        that.setData({
          data: res.data
        })
      },
      fail: function(res) {},
      complete: function(res) {},
    })

  },
  // 更换地址
  ghdz() {
    wx.navigateTo({
      url: '/pages/main/shippingAddressfk/shippingAddressfk',
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    })
  },
  // 确认支付
  tjdd() {

    var that = this;
    if (that.locked) return;
    that.locked=true;
    var goodsid = [{}];
    var delivery;

    if (that.data.navId == 1 && !this.data.address.id) {
      wx.showToast({
        title: '请先选择地址',
        icon: '',
        image: '/pages/image/cuohao.png',
        duration: 2000,
        mask: true,
        success: function(res) {},
        fail: function(res) {},
        complete: function(res) {},
      });
      that.locked=false;
      return;
    }

    console.log(that.data.data[0].goods[0].id)
    // for (var i in that.data.data[0].goods) {
    //   goodsid[i].goods = that.data.data[0].goods[i].id
    //   goodsid[i].quantity = that.data.data[0].goods[i].quantity
    //   goodsid[i].sku = that.data.data[0].goods[i].sku
    // }
    // console.log(goodsid)
    if (that.data.navId == 1) {
      delivery = 'express'
    } else if (that.data.navId == 2) {
      delivery = 'self'
    }


    wx.request({
      url: app.url + '/api/order',
      data: {
        address: morendizhi,
        goods: app.globalData.goodsobj,
        delivery: delivery,
        message: that.data.mjly
      },
      header: {
        'client-token': app.globalData.token
      },
      method: 'POST',
      dataType: 'json',
      responseType: 'text',
      success: function(res) {
        var orders=[];
        if (res.data.code == 0) {
          for (var i = 0; i < res.data.data.orders.length; i++) {
            orders.push(res.data.data.orders[i].id)
          }
        }

        wx.request({
          url: app.url + '/api/payment',
          data: {
            orders: orders,
            type: 'weixin:wxapp'
          },
          header: {
            'client-token': app.globalData.token
          },
          method: 'POST',
          dataType: 'json',
          responseType: 'text',
          success: function (res) {
            console.log(res)
            if (res.data.code == 0) {
              if (res.data.data.params == 'success') {
                that.locked = false;
                wx.navigateTo({
                  url: '/pages/main/orderfrom/orderfrom?id=2',
                  success: function (res) { },
                  fail: function (res) { },
                  complete: function (res) { },
                })
              } else {
                wx.requestPayment({
                  timeStamp: res.data.data.params.timeStamp,
                  nonceStr: res.data.data.params.nonceStr,
                  package: res.data.data.params.package,
                  signType: 'MD5',
                  paySign: res.data.data.params.paySign,
                  success(res) {
                    that.locked = false;
                    console.log(res)
                    that.setData({
                      dingdanjy: true
                    })
                    wx.navigateTo({
                      url: '/pages/main/orderfrom/orderfrom?id=2',
                      success: function (res) { },
                      fail: function (res) { },
                      complete: function (res) { },
                    })
                  },
                  fail(res) {
                    that.locked = false;
                   }
                })
              }

            }
          },
          fail: function (res) {
            that.locked = false;
          },
          complete: function (res) { },
        })
      },
      fail: function(res) {
        that.locked = false;
      },
      complete: function(res) {},
    })


  },
  // 获取买家留言
  mjly(e) {
    console.log(e.detail.value)
    var that = this;
    that.setData({
      mjly: e.detail.value
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    if (app.globalData.address) {
      morendizhi = app.globalData.address;
      this.setData({
        address: app.globalData.address
      });
    }

    // var options;
    // // console.log(options,"新订单")
    // options = app.globalData.options
    // wx.setNavigationBarTitle({
    //   title: '确认订单',
    // })
    // var that = this;
    // console.log('地址查询', app.globalData, app.globalData.address)

    // wx.getStorage({
    //   key: 'config',
    //   success: function (res) {
    //     console.log(res.data)
    //     that.setData({
    //       sjxx: res.data
    //     })
    //   },
    //   fail: function (res) { },
    //   complete: function (res) { },
    // })

    // wx.getStorage({
    //   key: 'token',
    //   success: function (res) {
    //     wx.request({
    //       url: app.url + '/api/address',
    //       data: '',
    //       header: {
    //         'client-token': res.data
    //       },
    //       method: 'GET',
    //       dataType: 'json',
    //       responseType: 'text',
    //       success: function (res) {
    //         console.log(res)
    //         if (res.data.code == 0) {
    //           //  that.setData({
    //           //    dzlist:res.data.data
    //           //  })
    //           for (var a = 0; a < res.data.data.length; a++) {
    //             if (res.data.data[a].isDefault == true) {
    //               that.setData({
    //                 dizhizhanshi: true,
    //                 dzlist: res.data.data[a]
    //               })
    //               that.setData({
    //                 // xxzshdz: false,
    //                 xming: res.data.data[a].name,
    //                 dianhua: res.data.data[a].tel,
    //                 dizhi: res.data.data[a].province + res.data.data[a].city + res.data.data[a].district + res.data.data[a].detail,
    //                 address: app.globalData.address
    //               })
    //             }
    //           }
    //           console.log(res.data.data)
    //           console.log(res.data.data.length)
    //           if (res.data.data.length > 0) {
    //             that.setData({
    //               xxzshdz: false
    //             })
    //           } else {
    //             that.setData({
    //               xxzshdz: true
    //             })
    //           }
    //         }
    //       },
    //       fail: function (res) { },
    //       complete: function (res) { },
    //     })
    //   },
    //   fail: function (res) { },
    //   complete: function (res) { },
    // })
    // wx.getStorage({
    //   key: 'orders',
    //   success: function (res) {
    //     console.log(res.data,"进入页面的新订单")
    //     that.setData({
    //       data: res.data
    //     })
    //   },
    //   fail: function (res) { },
    //   complete: function (res) { },
    // })
    // setTimeout(function () {
    //   console.log(that.data.data)
    //   that.setData({
    //     data: that.data.data
    //   })
    //   console.log(options)
    //   if (options.name) {
    //     console.log(111)
    //     that.setData({
    //       dizhizhanshi: true,
    //       // xxzshdz: false,
    //       xming: options.name,
    //       dianhua: options.tel,
    //       dizhi: options.dizhi,
    //       address: app.globalData.address
    //     })
    //     console.log(that.data.xming)
    //   }
    // }, 1000)

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})