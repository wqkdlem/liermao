// pages/main/fbHistory/fbHistory.js
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
     list:[
       {fknr:"无法提现！！",hfnr:"系统繁忙，请尝试！",data:"07/03",time:"7月03日 10:35"},
       {fknr:"无法提现！！",hfnr:"系统繁忙，请尝试！",data:"07/03",time:"7月03日 10:35"}
     ],
     time:[],
     time2:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.setNavigationBarTitle({
      title: '反馈历史',
    })
    var that = this;
    wx.getStorage({
      key: 'token',
      success: function(res) {
        wx.request({
          url: app.url +'/api/feedback/paginate',
          data: '',
          header: { 'client-token': res.data},
          method: 'GET',
          dataType: 'json',
          responseType: 'text',
          success: function(res) {
            console.log(res)
            if(res.data.code==0){
              that.setData({
                list: res.data.data.results
              })
              // var data = res.data.data.results[0].createdAt
              // console.log(data)
              // // var data1 = data.toString()
              // // console.log(data1)
              // var data_m = data.toString().split('T', 1)[0].split('-')[1]
              // var data_d = data.toString().split('T', 1)[0].split('-')[2]
              // var data_jz2 = data.toString().split('Z')[0].split('T')[1].split(':',2)[1]
              // var data_jz1 = data.toString().split('Z')[0].split('T')[1].split(':', 2)[0]
              // console.log(data_m)
              // console.log(data_d)
              // console.log(data_jz1)
              // console.log(data_jz2)
              for (var i in res.data.data.results){
                that.data.list[i].time = res.data.data.results[i].createdAt.toString().split('T', 1)[0].split('-')[1] + '/' + res.data.data.results[i].createdAt.toString().split('T', 1)[0].split('-')[2]
                that.data.list[i].time2 = res.data.data.results[i].createdAt.toString().split('T', 1)[0].split('-')[1] + '月' + res.data.data.results[i].createdAt.toString().split('T', 1)[0].split('-')[2] + '日' + '  ' + res.data.data.results[i].createdAt.toString().split('Z')[0].split('T')[1].split(':', 2)[0] + ':' + res.data.data.results[i].createdAt.toString().split('Z')[0].split('T')[1].split(':', 2)[1]
              }
              console.log(that.data.list)
              that.setData({
                list:that.data.list
              })
            }
          },
          fail: function(res) {},
          complete: function(res) {},
        })
      },
      fail: function(res) {},
      complete: function(res) {},
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})