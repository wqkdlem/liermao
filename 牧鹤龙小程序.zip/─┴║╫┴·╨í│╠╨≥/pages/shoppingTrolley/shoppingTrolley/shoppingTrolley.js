// pages/shoppingTrolley/shoppingTrolley/shoppingTrolley.js
var app = getApp()
var newlist=[];
Page({

  /**
   * 页面的初始数据
   */
  data: {
    list:"",
    gwcsfwk: true,
    jsorsc:true,
    aa:[],
    aaid:[],
    xaunkuang:false,
    heji:0.00
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that= this;
    that.setData({
      aa: [],
      aaid: [],
    })
    wx.setNavigationBarTitle({
      title: '购物车'
    });
  },
  bj(){
   var that = this;
   that.setData({
     jsorsc:!that.data.jsorsc
   })
  },
  // 选择
  xuanze(e){
    var that = this;
    let aa = that.data.aa
    let aaid = that.data.aaid
    console.log(e.currentTarget.dataset.je)
    console.log(e.currentTarget.dataset.sl)
    
    console.log(e.currentTarget.dataset.index)
    if (aa.indexOf(e.currentTarget.dataset.index) == -1) {
      
      that.setData({
        heji: that.data.heji + (e.currentTarget.dataset.je * e.currentTarget.dataset.sl)
      })
      aa.push(e.currentTarget.dataset.index)
      aaid.push(e.currentTarget.dataset.id)
      that.setData({
        aa: aa,
        aaid: aaid
      })
      console.log(that.data.aa)
      console.log(aaid)
      if (that.data.aa.length==that.data.list.length){
        
          that.setData({
            xaunkuang: true,
          })
      }else{
        that.setData({
          xaunkuang: false,
        })
      }
    } else {
      console.log(1)
      let index = aa.indexOf(e.currentTarget.dataset.index)
      that.setData({
        heji: that.data.heji - (e.currentTarget.dataset.je * e.currentTarget.dataset.sl)
      })
      aa.splice(index, 1)
      aaid.splice(index, 1)
      that.setData({
        aa: aa,
        aaid: aaid
      })
      console.log(that.data.aa)
      console.log(that.data.aaid)
      if (that.data.aa.length == that.data.list.length) {

        that.setData({
          xaunkuang: true,
        })
      } else {
        that.setData({
          xaunkuang: false,
        })
      }
    }
  },
  // 删除事件
  shanchu(){
    var that = this;
    console.log(that.data.list[that.data.aa[0]].id)
    for (let a = 0; a < that.data.aa.length; a++) {
      (function (a) {
        var id = that.data.list[that.data.aa[a]].id
        console.log(id)
        wx.getStorage({
          key: 'token',
          success: function (res) {
            wx.request({
              url: app.url + '/api/cart-goods/'+id,
              data: {
                id,
              },
              header: { 'client-token': res.data},
              method: 'DELETE',
              dataType: 'json',
              responseType: 'text',
              success: function (res) {
                console.log(res)
                if(res.data.code==0){
                  wx.showToast({
                    title: '删除成功',
                    icon: '',
                    image: '',
                    duration: 1000,
                    mask: true,
                    success: function(res) {

                    },
                    fail: function(res) {},
                    complete: function(res) {},
                  })
                  wx.getStorage({
                    key: 'token',
                    success: function (res) {
                      wx.request({
                        url: app.url + '/api/cart-goods',
                        data: '',
                        header: { 'client-token': res.data },
                        method: 'GET',
                        dataType: 'json',
                        responseType: 'text',
                        success: function (res) {
                          console.log(res)
                          console.log(res.data.data.length)
                          if (res.data.code == 0) {
                            if (res.data.data.length == 0) {
                              that.setData({
                                gwcsfwk: true
                              })
                            } else {
                              that.setData({
                                list: res.data.data,
                                gwcsfwk: false
                              })
                            }

                          }
                        },
                        fail: function (res) { },
                        complete: function (res) { },
                      })
                    },
                    fail: function (res) { },
                    complete: function (res) { },
                  })
                }
              },
              fail: function (res) { },
              complete: function (res) { },
            })
          },
          fail: function (res) { },
          complete: function (res) { },
        })
      })(a)

    }
  },
  // 全选事件
  quanxuan(){
    var that = this;
    let list = that.data.list

    console.log(newlist.length)
    console.log(that.data.aa.length)
    if (newlist.length != 0 && that.data.aa.length == newlist.length) {
      newlist=[]
      this.setData({
        aa: [],
        xaunkuang: false,
        heji: 0.00,
        aaid: [],
      })
    } else {
      this.setData({
        heji: 0.00,
        aaid:[]
      })
      for (let i = 0; i < list.length; i++) {
        newlist.push(i)
        that.data.aaid.push(that.data.list[i].id)
        that.setData({
          aaid: that.data.aaid,
          heji: that.data.heji + (that.data.list[i].price * that.data.list[i].quantity)
        })
      }
      console.log(that.data.aaid)
      console.log(newlist)
      this.setData({
        aa: newlist,
        xaunkuang: true
      })
    }
  },
  // 结算事件
  jiesuan() {
    var that = this;
    // console.log(that.data.list[that.data.aa[0]].id)
    // console.log(JSON.stringify(that.data.aaid))
    var gwcsp = []
    for (let a = 0; a < that.data.aa.length; a++) {
      // (function (a) {
        var id = that.data.list[that.data.aa[a]].id
      gwcsp.push(that.data.list[that.data.aa[a]])
    }
        wx.getStorage({
          key: 'token',
          success: function (res) {
            var liebiao = []
            for (let a in gwcsp) {
              
              var attr = { goods: '', quantity:'', sku:''}
              console.log(attr)
              attr.goods = gwcsp[a].goods
              attr.quantity = gwcsp[a].quantity
              attr.sku = gwcsp[a].sku
              console.log(attr)
              liebiao.push(attr)
            }
            var goodsobj = liebiao
            console.log(goodsobj)
            app.globalData.goodsobj = goodsobj;
            wx.request({
              url: app.url + '/api/order/pre-create',
              data: {
                goods: goodsobj
              },
              header: { 'client-token': res.data },
              method: 'POST',
              dataType: 'json',
              responseType: 'text',
              success: function (res) {
                console.log(res)
                var orders = res.data.data.orders
                if (res.data.code == 0) {
                  wx.setStorage({
                    key: 'orders',
                    data: orders,
                    success: function (res) { },
                    fail: function (res) { },
                    complete: function (res) { },
                  })
                  wx.navigateTo({
                    url: '/pages/main/confirmAnOrder/confirmAnOrder',
                    success: function (res) {
                      
                    },
                    fail: function (res) { },
                    complete: function (res) { },
                  })
                }
              },
              fail: function (res) { },
              complete: function (res) { },
            })
          },
          fail: function (res) { },
          complete: function (res) { },
        })
      // })(a)

    
  },
  // 更新列表
  fn(){
    
  },
  // 跳转到首页事件
  qsy(){
    wx.switchTab({
      url: '/pages/homepage/home/home',
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    })
  },
  //购物车数量减少事件
  jiangwcsl(e) {
    var that = this;
    console.log(e.currentTarget.dataset.shuliang)

    var shuliang = e.currentTarget.dataset.shuliang
    var id = e.currentTarget.dataset.id
    if (shuliang == 1) {
      wx.showToast({
        title: '该宝贝不能减少了',
        image: '/pages/image/cuohao.png',
        duration: 2000,
        mask: true,
        success: function(res) {},
        fail: function(res) {},
        complete: function(res) {},
      })
     }
    else if (shuliang > 1) {
      wx.getStorage({
        key: 'token',
        success: function(res) {
          wx.request({
            url: app.url + '/api/cart-goods/' + id,
            data: {
              quantity: shuliang - 1
            },
            header: { 'client-token': res.data},
            method: 'PUT',
            dataType: 'json',
            responseType: 'text',
            success: function (res) {
              console.log(res)
              if(res.data.code==0){
                wx.getStorage({
                  key: 'token',
                  success: function (res) {
                    wx.request({
                      url: app.url + '/api/cart-goods',
                      data: '',
                      header: { 'client-token': res.data },
                      method: 'GET',
                      dataType: 'json',
                      responseType: 'text',
                      success: function (res) {
                        console.log(res)
                        if (res.data.code == 0) {
                          that.setData({
                            list: res.data.data
                          })
                        }
                      },
                      fail: function (res) { },
                      complete: function (res) { },
                    })
                  },
                  fail: function (res) { },
                  complete: function (res) { },
                })
              }
            },
            fail: function (res) { },
            complete: function (res) { },
          })
        },
        fail: function(res) {},
        complete: function(res) {},
      })
      
    }

  },
  // 购物车数量增加事件
  jiagwcsj(e) {
    var that = this;
    console.log(e.currentTarget.dataset.shuliang)

    var shuliang = e.currentTarget.dataset.shuliang
    var id = e.currentTarget.dataset.id
    wx.getStorage({
      key: 'token',
      success: function (res) {
        wx.request({
          url: app.url + '/api/cart-goods/' + id,
          data: {
            quantity: shuliang + 1
          },
          header: { 'client-token': res.data },
          method: 'PUT',
          dataType: 'json',
          responseType: 'text',
          success: function (res) {
            console.log(res)
            if (res.data.code == 0) {
              wx.getStorage({
                key: 'token',
                success: function (res) {
                  wx.request({
                    url: app.url + '/api/cart-goods',
                    data: '',
                    header: { 'client-token': res.data },
                    method: 'GET',
                    dataType: 'json',
                    responseType: 'text',
                    success: function (res) {
                      console.log(res)
                      if (res.data.code == 0) {
                        that.setData({
                          list: res.data.data
                        })
                      }
                    },
                    fail: function (res) { },
                    complete: function (res) { },
                  })
                },
                fail: function (res) { },
                complete: function (res) { },
              })
            }
          },
          fail: function (res) { },
          complete: function (res) { },
        })
      },
      fail: function (res) { },
      complete: function (res) { },
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    that.setData({
      jsorsc: true,
      aa:[],
      xaunkuang: false,
      heji: 0.00,
      aaid:[]
    })
    wx.getStorage({
      key: 'token',
      success: function (res) {
        wx.request({
          url: app.url + '/api/cart-goods',
          data: '',
          header: { 'client-token': res.data },
          method: 'GET',
          dataType: 'json',
          responseType: 'text',
          success: function (res) {
            console.log(res)
            console.log(res.data.data.length)
            if (res.data.code == 0) {
              if (res.data.data.length == 0) {
                that.setData({
                  gwcsfwk: true
                })
              } else {
                that.setData({
                  list: res.data.data,
                  gwcsfwk: false
                })
              }

            }
          },
          fail: function (res) { },
          complete: function (res) { },
        })
      },
      fail: function (res) { },
      complete: function (res) { },
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})